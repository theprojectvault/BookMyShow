import os
import time
import uuid
from threading import Lock
import requests
import redis
from flask import Flask, jsonify, request
from common.config import REDIS_URL, SEAT_SERVICE_URL, REQUEST_TIMEOUT

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5002"))
INSTANCE = os.getenv("INSTANCE_NAME", f"booking-{PORT}")

START_TIME = time.time()
REQUEST_COUNT = 0
CONFIRMED_COUNT = 0
REJECTED_COUNT = 0
SIMULATED_DOWN = False

# Try Redis
redis_available = False
r = None
try:
    r = redis.Redis.from_url(REDIS_URL, decode_responses=True, socket_connect_timeout=1.5)
    r.ping()
    redis_available = True
except Exception:
    redis_available = False

# Fallback in-memory storage if Redis is offline
mem_lock = Lock()
mem_bookings = {}
mem_idempotency = {}
recent_bookings_list = []

@app.before_request
def check_fault():
    if request.path.startswith("/dev/"):
        return None
    if SIMULATED_DOWN:
        return jsonify(
            error="Booking service temporarily unavailable (simulated fault injection)",
            status="DOWN",
            service=INSTANCE,
            port=PORT
        ), 503

@app.get("/health")
def health():
    if SIMULATED_DOWN:
        return jsonify(
            status="DOWN",
            service="booking-service",
            instance=INSTANCE,
            port=PORT,
            fault_injected=True
        ), 503

    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    return jsonify(
        status="UP",
        service="booking-service",
        instance=INSTANCE,
        port=PORT,
        role="Transaction Coordinator & Idempotency Engine",
        redis="UP" if current_redis_up else "FALLBACK_IN_MEMORY",
        dependencies={"seat_service": SEAT_SERVICE_URL},
        uptime_seconds=int(time.time() - START_TIME),
        request_count=REQUEST_COUNT,
        confirmed_count=CONFIRMED_COUNT,
        rejected_count=REJECTED_COUNT
    )

@app.post("/bookings")
def create_booking():
    global REQUEST_COUNT, CONFIRMED_COUNT, REJECTED_COUNT
    REQUEST_COUNT += 1

    data = request.get_json(silent=True) or {}
    show_id = str(data.get("show_id", "")).strip()
    seat_id = str(data.get("seat_id", "")).strip().upper()
    customer_name = str(data.get("customer_name") or data.get("customer") or "Valued Guest").strip()
    movie_title = str(data.get("movie_title", "Cinema Showcase")).strip()
    theatre = str(data.get("theatre", "Multiplex Screen")).strip()
    show_time = str(data.get("show_time", "19:00")).strip()
    price = float(data.get("price", 280.0))

    idempotency_key = request.headers.get("Idempotency-Key") or str(data.get("idempotency_key", "")).strip()

    if not show_id or not seat_id:
        return jsonify(error="Both show_id and seat_id are required fields."), 400
    if not idempotency_key:
        return jsonify(error="Provide an Idempotency-Key header or idempotency_key field to prevent duplicate submissions."), 400

    idem_key = f"idempotency:{idempotency_key}"

    # Check if Redis is up
    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    # 1. IDEMPOTENCY CHECK
    existing_id = None
    if current_redis_up:
        try:
            existing_id = r.get(idem_key)
        except Exception:
            existing_id = mem_idempotency.get(idem_key)
    else:
        with mem_lock:
            existing_id = mem_idempotency.get(idem_key)

    if existing_id:
        existing_record = None
        if current_redis_up:
            try:
                existing_record = r.hgetall(f"booking:{existing_id}")
            except Exception:
                existing_record = mem_bookings.get(existing_id)
        else:
            with mem_lock:
                existing_record = mem_bookings.get(existing_id)

        if existing_record:
            return jsonify(
                status="EXISTING",
                message="Idempotent request recognized: returning previously created booking record without re-processing.",
                booking=existing_record,
                idempotency_key=idempotency_key,
                service=INSTANCE
            ), 200

    booking_id = f"BMS-{uuid.uuid4().hex[:8].upper()}"

    # 2. CALL SEAT SERVICE (Inter-process communication & Service Dependency)
    try:
        seat_response = requests.post(
            f"{SEAT_SERVICE_URL}/seats/reserve",
            json={
                "show_id": show_id,
                "seat_id": seat_id,
                "booking_id": booking_id,
                "customer": customer_name
            },
            timeout=REQUEST_TIMEOUT
        )
    except requests.RequestException as exc:
        # Service dependency failure demonstration
        REJECTED_COUNT += 1
        return jsonify(
            error="Upstream Service Dependency Failure",
            dependency="seat_service",
            port=5003,
            detail=f"Seat Service at {SEAT_SERVICE_URL} is unreachable: {exc}",
            concept="Service Dependency Handling: The Booking Service cannot finalize reservations when its prerequisite Seat Service is offline."
        ), 503

    # 3. HANDLE UPSTREAM FAILURES & CONFLICTS
    if seat_response.status_code == 503:
        REJECTED_COUNT += 1
        return jsonify(
            error="Upstream Service Dependency Failure",
            dependency="seat_service",
            port=5003,
            detail="Seat Service at port 5003 returned 503 Service Unavailable.",
            concept="Service Dependency Handling: The Booking Service cannot finalize reservations when its prerequisite Seat Service is offline."
        ), 503

    if seat_response.status_code == 409:
        REJECTED_COUNT += 1
        conflict_payload = {}
        try:
            conflict_payload = seat_response.json()
        except Exception:
            conflict_payload = {"message": seat_response.text}
        return jsonify(
            status="REJECTED",
            message=f"Seat {seat_id} is already reserved for this show.",
            seat_id=seat_id,
            show_id=show_id,
            reason=conflict_payload.get("conflict_reason", "Conflict detected by Seat Authority"),
            upstream_detail=conflict_payload,
            service=INSTANCE
        ), 409

    if seat_response.status_code not in (200, 201):
        REJECTED_COUNT += 1
        return jsonify(
            error="Seat reservation operation failed upstream",
            upstream_status=seat_response.status_code,
            detail=seat_response.text[:300]
        ), 502

    # 4. COMPOSE AND PERSIST BOOKING RECORD
    booking_record = {
        "booking_id": booking_id,
        "show_id": show_id,
        "seat_id": seat_id,
        "movie_title": movie_title,
        "theatre": theatre,
        "show_time": show_time,
        "customer_name": customer_name,
        "ticket_price": str(price),
        "convenience_fee": "35.00",
        "total_amount": f"{price + 35.0:.2f}",
        "status": "CONFIRMED",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "created_by": INSTANCE,
        "engine": "Distributed Microservice Pipeline"
    }

    if current_redis_up:
        try:
            pipe = r.pipeline(transaction=True)
            pipe.hset(f"booking:{booking_id}", mapping=booking_record)
            pipe.set(idem_key, booking_id)
            pipe.execute()
        except Exception:
            with mem_lock:
                mem_bookings[booking_id] = booking_record
                mem_idempotency[idem_key] = booking_id
    else:
        with mem_lock:
            mem_bookings[booking_id] = booking_record
            mem_idempotency[idem_key] = booking_id

    with mem_lock:
        recent_bookings_list.insert(0, booking_record)
        del recent_bookings_list[50:]

    CONFIRMED_COUNT += 1
    return jsonify(
        status="CONFIRMED",
        message="Reservation successful! Ticket generated.",
        booking=booking_record,
        seat_service_result=seat_response.json(),
        service=INSTANCE
    ), 201

@app.get("/bookings/<booking_id>")
def get_booking(booking_id):
    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    record = None
    if current_redis_up:
        try:
            record = r.hgetall(f"booking:{booking_id}")
        except Exception:
            record = mem_bookings.get(booking_id)
    else:
        with mem_lock:
            record = mem_bookings.get(booking_id)

    if not record:
        return jsonify(error="Booking record not found", booking_id=booking_id), 404
    return jsonify(booking=record, service=INSTANCE)

@app.get("/bookings/history")
def get_history():
    return jsonify(
        bookings=recent_bookings_list[:20],
        total=len(recent_bookings_list),
        service=INSTANCE
    )

@app.post("/dev/simulate_crash")
def simulate_crash():
    global SIMULATED_DOWN
    SIMULATED_DOWN = True
    return jsonify(action="crash", status="DOWN", service=INSTANCE, port=PORT), 200

@app.post("/dev/simulate_recover")
def simulate_recover():
    global SIMULATED_DOWN
    SIMULATED_DOWN = False
    return jsonify(action="recover", status="UP", service=INSTANCE, port=PORT), 200

if __name__ == "__main__":
    print(f"[{INSTANCE}] Starting Booking Service on http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
