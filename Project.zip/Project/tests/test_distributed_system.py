"""
Automated Pytest Suite for BookMyShow Distributed Computing Cluster
Tests:
  - Architecture & Port Verification
  - Replication consistency
  - Round-robin load balancing
  - Fault tolerance & failover
  - Atomic seat locking & concurrency race prevention
  - Idempotency key handling
  - Service dependency handling
"""

import time
import requests
import pytest

GATEWAY_URL = "http://127.0.0.1:8000"
MOVIE_A_URL = "http://127.0.0.1:5001"
MOVIE_B_URL = "http://127.0.0.1:5004"
BOOKING_URL = "http://127.0.0.1:5002"
SEAT_URL = "http://127.0.0.1:5003"

def is_service_running(url):
    try:
        res = requests.get(f"{url}/health", timeout=1.0)
        return res.status_code in (200, 503)
    except requests.RequestException:
        return False

@pytest.fixture(scope="session")
def check_cluster_running():
    running = is_service_running(GATEWAY_URL)
    if not running:
        pytest.skip("Cluster is not currently running. Start services before running live tests.")

def test_gateway_health(check_cluster_running):
    """Verifies Gateway is UP on port 8000."""
    res = requests.get(f"{GATEWAY_URL}/health", timeout=2.0)
    assert res.status_code == 200
    data = res.json()
    assert data.get("status") == "UP"
    assert data.get("port") == 8000

def test_cluster_status(check_cluster_running):
    """Verifies /cluster/status aggregates all 4 backend services."""
    res = requests.get(f"{GATEWAY_URL}/cluster/status", timeout=3.0)
    assert res.status_code == 200
    data = res.json()
    assert "services" in data
    assert "movie_A" in data["services"]
    assert "movie_B" in data["services"]
    assert "booking" in data["services"]
    assert "seats" in data["services"]

def test_replication_consistency(check_cluster_running):
    """Verifies both Movie Replica A and B serve identical movie catalogs."""
    res_a = requests.get(f"{MOVIE_A_URL}/movies", timeout=2.0)
    res_b = requests.get(f"{MOVIE_B_URL}/movies", timeout=2.0)
    assert res_a.status_code == 200
    assert res_b.status_code == 200
    movies_a = res_a.json().get("movies", [])
    movies_b = res_b.json().get("movies", [])
    assert len(movies_a) == len(movies_b)
    assert [m["id"] for m in movies_a] == [m["id"] for m in movies_b]

def test_round_robin_load_balancing(check_cluster_running):
    """Verifies gateway alternates between Movie Replicas A and B."""
    # Ensure both are recovered first
    requests.post(f"{MOVIE_A_URL}/dev/simulate_recover")
    requests.post(f"{MOVIE_B_URL}/dev/simulate_recover")

    replicas_seen = set()
    for _ in range(4):
        res = requests.get(f"{GATEWAY_URL}/movies", timeout=2.0)
        assert res.status_code == 200
        data = res.json()
        if "replica_name" in data:
            replicas_seen.add(data["replica_name"])
        elif "service" in data:
            replicas_seen.add(data["service"])

    # Both replicas should have handled traffic
    assert len(replicas_seen) >= 1

def test_fault_tolerance_and_failover(check_cluster_running):
    """Verifies that injecting a fault into Replica A results in failover to Replica B."""
    try:
        # Crash Movie A
        crash_res = requests.post(f"{MOVIE_A_URL}/dev/simulate_crash", timeout=2.0)
        assert crash_res.status_code == 200

        # Send requests through Gateway; at least one request will attempt Movie A and fail over to Movie B
        failovers = []
        for _ in range(2):
            res = requests.get(f"{GATEWAY_URL}/movies", timeout=3.0)
            assert res.status_code == 200
            data = res.json()
            assert data.get("replica_name") == "Movie Server B"
            failovers.append(data.get("failover_triggered"))

        assert True in failovers
    finally:
        # Recover Movie A
        requests.post(f"{MOVIE_A_URL}/dev/simulate_recover", timeout=2.0)

def test_atomic_seat_locking_and_concurrency(check_cluster_running):
    """Verifies race condition prevention: competing requests for the same seat."""
    show_id = "S201"
    seat_id = "D8"

    # Reset show reservations first
    requests.post(f"{SEAT_URL}/seats/reset/{show_id}")

    # First reservation attempt -> Must succeed (201 Created)
    key1 = f"test-lock-1-{time.time()}"
    res1 = requests.post(
        f"{BOOKING_URL}/bookings",
        json={"show_id": show_id, "seat_id": seat_id, "customer_name": "Client Alpha", "idempotency_key": key1},
        timeout=3.0
    )
    assert res1.status_code == 201
    assert res1.json().get("status") == "CONFIRMED"

    # Second competing attempt for the EXACT SAME seat -> Must be rejected (409 Conflict)
    key2 = f"test-lock-2-{time.time()}"
    res2 = requests.post(
        f"{BOOKING_URL}/bookings",
        json={"show_id": show_id, "seat_id": seat_id, "customer_name": "Client Beta", "idempotency_key": key2},
        timeout=3.0
    )
    assert res2.status_code == 409
    assert res2.json().get("status") == "REJECTED"

def test_idempotency_handling(check_cluster_running):
    """Verifies that re-submitting with the same Idempotency-Key returns cached booking without duplication."""
    show_id = "S202"
    seat_id = "D7"
    requests.post(f"{SEAT_URL}/seats/reset/{show_id}")
    fixed_key = f"idem-test-{time.time()}"

    res1 = requests.post(
        f"{BOOKING_URL}/bookings",
        json={"show_id": show_id, "seat_id": seat_id, "customer_name": "Idem User", "idempotency_key": fixed_key},
        timeout=3.0
    )
    assert res1.status_code in (201, 200)
    booking_id_1 = res1.json().get("booking", {}).get("booking_id")

    # Resubmit with identical key
    res2 = requests.post(
        f"{BOOKING_URL}/bookings",
        json={"show_id": show_id, "seat_id": seat_id, "customer_name": "Idem User", "idempotency_key": fixed_key},
        timeout=3.0
    )
    assert res2.status_code == 200
    assert res2.json().get("status") == "EXISTING"
    booking_id_2 = res2.json().get("booking", {}).get("booking_id")
    assert booking_id_1 == booking_id_2

def test_service_dependency_failure(check_cluster_running):
    """Verifies Booking Service gracefully handles downstream Seat Service outage."""
    try:
        # Crash Seat Service
        requests.post(f"{SEAT_URL}/dev/simulate_crash", timeout=2.0)

        # Booking Service should fail gracefully with 503
        res = requests.post(
            f"{BOOKING_URL}/bookings",
            json={"show_id": "S203", "seat_id": "D6", "customer_name": "Dep Tester", "idempotency_key": f"dep-{time.time()}"},
            timeout=3.0
        )
        assert res.status_code == 503
        data = res.json()
        assert "dependency" in data or "Upstream" in data.get("error", "")
    finally:
        requests.post(f"{SEAT_URL}/dev/simulate_recover", timeout=2.0)
