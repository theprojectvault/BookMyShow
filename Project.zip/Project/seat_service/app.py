import os
import time
from threading import Lock
from flask import Flask, jsonify, request
import redis
from common.config import REDIS_URL

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5003"))
INSTANCE = os.getenv("INSTANCE_NAME", f"seat-{PORT}")

START_TIME = time.time()
REQUEST_COUNT = 0
RESERVE_COUNT = 0
CONFLICT_COUNT = 0
SIMULATED_DOWN = False

# Try Redis connection
redis_available = False
r = None
try:
    r = redis.Redis.from_url(REDIS_URL, decode_responses=True, socket_connect_timeout=1.5)
    r.ping()
    redis_available = True
except Exception:
    redis_available = False

# Redis Lua Script for Atomic Reservation
RESERVE_LUA = """
local key = KEYS[1]
local booking_id = ARGV[1]
local customer = ARGV[2]
local ts = ARGV[3]

if redis.call("EXISTS", key) == 1 then
    return 0
end

redis.call("HSET", key, "booking_id", booking_id, "customer", customer, "reserved_at", ts, "status", "RESERVED")
return 1
"""

reserve_script = None
if redis_available and r:
    try:
        reserve_script = r.register_script(RESERVE_LUA)
    except Exception:
        reserve_script = None

# Thread-safe in-memory fallback for environments without Redis
in_memory_lock = Lock()
in_memory_seats = {}

# Pre-seed realistic booked seats for demo immersion
INITIAL_BOOKED = {
    "S201": ["A3", "B5", "B6", "C4"],
    "S202": ["A2", "C3", "D4", "D5"],
    "S203": ["B2", "B3", "C5", "D1"],
    "S204": ["A4", "B4", "C6"],
    "S205": ["B1", "C2", "D3"],
    "S206": ["A1", "A2", "C1"]
}

def seed_initial_seats():
    global in_memory_seats
    for show_id, seat_list in INITIAL_BOOKED.items():
        for seat_id in seat_list:
            key = f"seat:{show_id}:{seat_id}"
            if redis_available and r:
                try:
                    if not r.exists(key):
                        r.hset(key, mapping={
                            "booking_id": "PRE-BOOKED-000",
                            "customer": "System Guest",
                            "reserved_at": str(time.time()),
                            "status": "RESERVED"
                        })
                except Exception:
                    pass
            with in_memory_lock:
                if key not in in_memory_seats:
                    in_memory_seats[key] = {
                        "booking_id": "PRE-BOOKED-000",
                        "customer": "System Guest",
                        "reserved_at": str(time.time()),
                        "status": "RESERVED"
                    }

seed_initial_seats()

ALL_SEATS = [f"{row}{col}" for row in "ABCD" for col in range(1, 9)]

@app.before_request
def check_fault():
    if request.path.startswith("/dev/"):
        return None
    if SIMULATED_DOWN:
        return jsonify(
            error="Seat service unavailable (simulated fault injection)",
            status="DOWN",
            service=INSTANCE,
            port=PORT
        ), 503

@app.get("/health")
def health():
    if SIMULATED_DOWN:
        return jsonify(
            status="DOWN",
            service="seat-service",
            instance=INSTANCE,
            port=PORT,
            fault_injected=True
        ), 503

    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    return jsonify(
        status="UP",
        service="seat-service",
        instance=INSTANCE,
        port=PORT,
        role="Seat Inventory & Atomic Mutex Authority",
        redis="UP" if current_redis_up else "FALLBACK_IN_MEMORY",
        concurrency_engine="Redis Lua Atomic Mutex" if current_redis_up else "Python Lock Memory Mutex",
        uptime_seconds=int(time.time() - START_TIME),
        request_count=REQUEST_COUNT,
        reserved_count=RESERVE_COUNT,
        conflict_count=CONFLICT_COUNT
    )

@app.get("/seats/<show_id>")
def get_seats(show_id):
    global REQUEST_COUNT
    REQUEST_COUNT += 1

    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    output = []
    for seat_id in ALL_SEATS:
        key = f"seat:{show_id}:{seat_id}"
        record = {}
        if current_redis_up:
            try:
                record = r.hgetall(key)
            except Exception:
                record = in_memory_seats.get(key, {})
        else:
            with in_memory_lock:
                record = in_memory_seats.get(key, {})

        status = record.get("status", "AVAILABLE")
        row = seat_id[0]
        seat_type = "STANDARD" if row == "A" else ("EXECUTIVE" if row == "B" else ("VIP" if row == "C" else "RECLINER"))

        output.append({
            "seat_id": seat_id,
            "row": row,
            "status": status,
            "type": seat_type,
            "customer": record.get("customer", "") if status == "RESERVED" else ""
        })

    return jsonify(
        show_id=show_id,
        seats=output,
        total_seats=len(output),
        available_seats=sum(1 for s in output if s["status"] == "AVAILABLE"),
        service=INSTANCE,
        storage="Redis" if current_redis_up else "In-Memory Engine"
    )

@app.post("/seats/reserve")
def reserve_seat():
    global REQUEST_COUNT, RESERVE_COUNT, CONFLICT_COUNT
    REQUEST_COUNT += 1

    data = request.get_json(silent=True) or {}
    show_id = str(data.get("show_id", "")).strip()
    seat_id = str(data.get("seat_id", "")).strip().upper()
    booking_id = str(data.get("booking_id", "")).strip()
    customer = str(data.get("customer", "Guest Customer")).strip()

    if not show_id or not booking_id or seat_id not in ALL_SEATS:
        return jsonify(
            error="Validation failed. Provide valid show_id, booking_id, and seat_id (A1-D8).",
            status="INVALID_INPUT"
        ), 400

    key = f"seat:{show_id}:{seat_id}"
    ts = str(time.time())

    # Check if Redis is live
    current_redis_up = False
    if r:
        try:
            r.ping()
            current_redis_up = True
        except Exception:
            current_redis_up = False

    if current_redis_up and reserve_script:
        try:
            result = reserve_script(keys=[key], args=[booking_id, customer, ts])
            if int(result) == 0:
                CONFLICT_COUNT += 1
                existing = r.hgetall(key)
                return jsonify(
                    status="CONFLICT",
                    message=f"Seat {seat_id} is already reserved for show {show_id}.",
                    seat_id=seat_id,
                    show_id=show_id,
                    conflict_reason="Atomic mutual exclusion check detected existing reservation lock",
                    existing_booking_id=existing.get("booking_id"),
                    service=INSTANCE
                ), 409

            RESERVE_COUNT += 1
            return jsonify(
                status="RESERVED",
                message=f"Seat {seat_id} successfully reserved.",
                seat_id=seat_id,
                show_id=show_id,
                booking_id=booking_id,
                customer=customer,
                reserved_at=ts,
                engine="Redis Lua Atomic",
                service=INSTANCE
            ), 201
        except Exception as exc:
            pass # fall through to thread-safe memory lock

    # In-memory atomic fallback
    with in_memory_lock:
        if key in in_memory_seats:
            CONFLICT_COUNT += 1
            existing = in_memory_seats[key]
            return jsonify(
                status="CONFLICT",
                message=f"Seat {seat_id} is already reserved for show {show_id}.",
                seat_id=seat_id,
                show_id=show_id,
                conflict_reason="In-memory thread-safe mutex detected existing reservation lock",
                existing_booking_id=existing.get("booking_id"),
                service=INSTANCE
            ), 409

        in_memory_seats[key] = {
            "booking_id": booking_id,
            "customer": customer,
            "reserved_at": ts,
            "status": "RESERVED"
        }
        RESERVE_COUNT += 1
        return jsonify(
            status="RESERVED",
            message=f"Seat {seat_id} successfully reserved via memory mutex.",
            seat_id=seat_id,
            show_id=show_id,
            booking_id=booking_id,
            customer=customer,
            reserved_at=ts,
            engine="Python Thread-Safe Mutex",
            service=INSTANCE
        ), 201

@app.post("/seats/reset/<show_id>")
def reset_show_seats(show_id):
    """Resets all reservations for a show back to pre-seeded state for clean demo resets."""
    key_prefix = f"seat:{show_id}:"
    if r:
        try:
            keys = r.keys(f"{key_prefix}*")
            if keys:
                r.delete(*keys)
        except Exception:
            pass

    with in_memory_lock:
        for k in list(in_memory_seats.keys()):
            if k.startswith(key_prefix):
                del in_memory_seats[k]

    seed_initial_seats()
    return jsonify(status="RESET_SUCCESS", show_id=show_id, message=f"Show {show_id} seat map reset to initial state.")

@app.post("/dev/simulate_crash")
def simulate_crash():
    global SIMULATED_DOWN
    SIMULATED_DOWN = True
    return jsonify(action="crash", status="DOWN", service=INSTANCE, port=PORT), 200

@app.post("/dev/simulate_recover")
def simulate_recover():
    global SIMULATED_DOWN
    SIMULATED_DOWN = False
    return jsonify(action="recover", status="UP", service=INSTANCE, port=PORT), 200

if __name__ == "__main__":
    print(f"[{INSTANCE}] Starting Seat Service on http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
