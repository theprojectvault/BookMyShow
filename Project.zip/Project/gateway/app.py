import os
import time
import itertools
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
import requests
from flask import Flask, jsonify, request, render_template
from common.config import (
    MOVIE_REPLICAS,
    BOOKING_SERVICE_URL,
    SEAT_SERVICE_URL,
    REQUEST_TIMEOUT,
    SERVICES
)

app = Flask(
    __name__,
    template_folder="../dashboard",
    static_folder="../dashboard/static",
)

counter = itertools.count()
telemetry_lock = Lock()
routing_history = []
cluster_events = []

# Service URL mappings
SERVICE_MAP = {
    "movie_A": MOVIE_REPLICAS[0],
    "movie_B": MOVIE_REPLICAS[1],
    "booking": BOOKING_SERVICE_URL,
    "seats": SEAT_SERVICE_URL,
}

def log_event(message, kind="info", category="system"):
    with telemetry_lock:
        cluster_events.insert(0, {
            "time": time.strftime("%H:%M:%S"),
            "timestamp": time.time(),
            "message": message,
            "kind": kind,
            "category": category
        })
        del cluster_events[60:]

def try_movie_replicas(path):
    req_num = next(counter) + 1
    replicas = MOVIE_REPLICAS
    start = (req_num - 1) % len(replicas)
    errors = []
    t_start = time.time()
    
    for offset in range(len(replicas)):
        idx = (start + offset) % len(replicas)
        base = replicas[idx]
        replica_name = "Movie Server A" if idx == 0 else "Movie Server B"
        t0 = time.time()
        try:
            response = requests.get(f"{base}{path}", timeout=REQUEST_TIMEOUT)
            latency_ms = round((time.time() - t0) * 1000, 2)
            
            if response.status_code == 200:
                payload = response.json()
                failover = offset > 0
                failed_node = replicas[start] if failover else None
                
                payload["routed_to"] = base
                payload["replica_name"] = replica_name
                payload["request_number"] = req_num
                payload["latency_ms"] = latency_ms
                payload["failover_triggered"] = failover
                payload["attempts"] = offset + 1
                if failover:
                    payload["failed_replica"] = "Movie Server A" if start == 0 else "Movie Server B"
                    log_event(
                        f"Failover triggered: {payload['failed_replica']} was unavailable. Successfully rerouted to {replica_name} ({latency_ms}ms).",
                        kind="warning",
                        category="failover"
                    )
                else:
                    log_event(
                        f"Load Balancer: Request #{req_num} routed to {replica_name} ({base}) - {latency_ms}ms",
                        kind="good",
                        category="load_balancer"
                    )

                with telemetry_lock:
                    routing_history.insert(0, {
                        "request_number": req_num,
                        "replica": replica_name,
                        "url": base,
                        "latency_ms": latency_ms,
                        "status": 200,
                        "failover": failover,
                        "timestamp": time.strftime("%H:%M:%S")
                    })
                    del routing_history[50:]

                return jsonify(payload), 200
            else:
                errors.append(f"{replica_name} ({base}): HTTP {response.status_code}")
        except (requests.RequestException, ValueError) as exc:
            errors.append(f"{replica_name} ({base}): {str(exc)}")

    total_time = round((time.time() - t_start) * 1000, 2)
    log_event(
        f"All movie replicas failed after {len(replicas)} attempts ({total_time}ms).",
        kind="bad",
        category="failover"
    )
    with telemetry_lock:
        routing_history.insert(0, {
            "request_number": req_num,
            "replica": "None",
            "url": "N/A",
            "latency_ms": total_time,
            "status": 503,
            "failover": True,
            "timestamp": time.strftime("%H:%M:%S")
        })
    return jsonify(
        error="All movie service replicas are unavailable",
        request_number=req_num,
        attempts=len(replicas),
        details=errors,
        latency_ms=total_time
    ), 503

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Idempotency-Key"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response

@app.get("/")
def dashboard():
    return render_template("index.html")

@app.get("/health")
def health():
    return jsonify(
        status="UP",
        service="gateway",
        port=8000,
        role="Reverse Proxy & Load Balancer"
    )

@app.get("/movies")
def movies():
    return try_movie_replicas("/movies")

@app.get("/movies/<movie_id>")
def movie_detail(movie_id):
    return try_movie_replicas(f"/movies/{movie_id}")

@app.get("/shows")
def shows():
    return try_movie_replicas("/shows")

@app.get("/shows/<show_id>")
def show_detail(show_id):
    return try_movie_replicas(f"/shows/{show_id}")

@app.get("/cluster/status")
def cluster_status():
    services = {}
    total_up = 0
    t0 = time.time()
    
    for name, url in SERVICE_MAP.items():
        node_t0 = time.time()
        try:
            res = requests.get(f"{url}/health", timeout=REQUEST_TIMEOUT)
            node_latency = round((time.time() - node_t0) * 1000, 1)
            try:
                details = res.json()
            except ValueError:
                details = {"message": res.text[:200]}
            is_up = res.status_code == 200 and details.get("status") == "UP"
            if is_up:
                total_up += 1
            services[name] = {
                "name": SERVICES.get(name, {}).get("name", name),
                "status": "UP" if is_up else "DOWN",
                "port": SERVICES.get(name, {}).get("port"),
                "url": url,
                "latency_ms": node_latency,
                "details": details,
            }
        except (requests.RequestException, ValueError) as exc:
            services[name] = {
                "name": SERVICES.get(name, {}).get("name", name),
                "status": "DOWN",
                "port": SERVICES.get(name, {}).get("port"),
                "url": url,
                "error": str(exc),
                "details": {"status": "DOWN", "error": "Connection Refused / Offline"}
            }

    redis_up = services.get("seats", {}).get("details", {}).get("redis") == "UP"
    return jsonify(
        gateway="UP",
        gateway_port=8000,
        services=services,
        services_online=total_up,
        total_services=len(SERVICE_MAP),
        redis_status="UP" if redis_up else "FALLBACK",
        check_time_ms=round((time.time() - t0) * 1000, 1)
    )

@app.post("/cluster/control/<service_name>/<action>")
def cluster_control(service_name, action):
    """Controlled development-only fault injection and recovery."""
    if service_name not in SERVICE_MAP:
        return jsonify(error=f"Unknown service '{service_name}'"), 400
    if action not in ("crash", "recover"):
        return jsonify(error="Action must be 'crash' or 'recover'"), 400

    target_url = SERVICE_MAP[service_name]
    endpoint = f"{target_url}/dev/simulate_{'crash' if action == 'crash' else 'recover'}"
    service_label = SERVICES.get(service_name, {}).get("name", service_name)
    
    try:
        res = requests.post(endpoint, timeout=2.0)
        res_data = res.json() if res.status_code == 200 else {"error": res.text}
        
        log_event(
            f"Fault Laboratory: {service_label} injected with '{action.upper()}' action. Status: {res_data.get('status')}.",
            kind="warning" if action == "crash" else "good",
            category="fault_injection"
        )
        return jsonify(
            service=service_name,
            service_name=service_label,
            action=action,
            result=res_data,
            message=f"{service_label} is now {'DOWN' if action == 'crash' else 'UP'}."
        )
    except requests.RequestException as exc:
        return jsonify(
            error=f"Could not reach {service_label} at {target_url}: {exc}",
            hint="If the service was killed via Ctrl+C, it is already completely DOWN at the OS level."
        ), 503

@app.get("/api/seats/<show_id>")
def seat_status(show_id):
    try:
        response = requests.get(f"{SEAT_SERVICE_URL}/seats/{show_id}", timeout=REQUEST_TIMEOUT)
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException as exc:
        return jsonify(
            error="Seat Service is unavailable",
            detail=str(exc),
            concept="Service Dependency Handling: Seat availability cannot be fetched when Seat Service (port 5003) is offline."
        ), 503

@app.post("/seats/reset/<show_id>")
def reset_seats(show_id):
    try:
        response = requests.post(f"{SEAT_SERVICE_URL}/seats/reset/{show_id}", timeout=REQUEST_TIMEOUT)
        log_event(f"Seat reservations reset for show {show_id}.", kind="info", category="cinema")
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException as exc:
        return jsonify(error="Seat service unavailable", detail=str(exc)), 503

@app.post("/bookings")
def bookings():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="Send a valid JSON request body."), 400

    headers = {}
    if request.headers.get("Idempotency-Key"):
        headers["Idempotency-Key"] = request.headers["Idempotency-Key"]

    try:
        response = requests.post(
            f"{BOOKING_SERVICE_URL}/bookings",
            json=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT + 2,
        )
        try:
            payload = response.json()
        except ValueError:
            payload = {"error": response.text[:300]}

        seat = data.get("seat_id", "?")
        show = data.get("show_id", "?")
        if response.status_code in (200, 201):
            log_event(
                f"Booking Confirmed: Seat {seat} reserved for {show}. (ID: {payload.get('booking', {}).get('booking_id')})",
                kind="good",
                category="booking"
            )
        elif response.status_code == 409:
            log_event(
                f"Booking Rejected: Seat {seat} already reserved for {show}. Conflict detected.",
                kind="bad",
                category="concurrency"
            )
        return jsonify(payload), response.status_code
    except requests.RequestException as exc:
        log_event(f"Booking service unreachable: {exc}", kind="bad", category="booking")
        return jsonify(
            error="Booking service unavailable",
            detail=str(exc),
            concept="Service Dependency Failure: API Gateway cannot reach Booking Service (port 5002)."
        ), 503

@app.get("/bookings/<booking_id>")
def get_booking(booking_id):
    try:
        response = requests.get(f"{BOOKING_SERVICE_URL}/bookings/{booking_id}", timeout=REQUEST_TIMEOUT)
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException as exc:
        return jsonify(error="Booking service unavailable", detail=str(exc)), 503

@app.get("/bookings/history")
def get_booking_history():
    try:
        response = requests.get(f"{BOOKING_SERVICE_URL}/bookings/history", timeout=REQUEST_TIMEOUT)
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException:
        return jsonify(bookings=[], total=0)

@app.post("/cluster/concurrency_test")
def run_concurrency_test():
    """Executes a simultaneous race condition test against the same seat."""
    data = request.get_json(silent=True) or {}
    show_id = str(data.get("show_id", "S201")).strip()
    seat_id = str(data.get("seat_id", "B4")).strip().upper()
    concurrency_count = int(data.get("count", 3))

    results = []

    def send_attempt(index):
        user_name = f"Concurrent Tester #{index+1}"
        idem_key = f"race-test-{show_id}-{seat_id}-{time.time()}-{index}"
        t0 = time.time()
        try:
            res = requests.post(
                f"{BOOKING_SERVICE_URL}/bookings",
                json={
                    "show_id": show_id,
                    "seat_id": seat_id,
                    "customer_name": user_name,
                    "idempotency_key": idem_key
                },
                timeout=3.0
            )
            lat = round((time.time() - t0) * 1000, 2)
            try:
                body = res.json()
            except Exception:
                body = {"text": res.text}
            return {
                "client": user_name,
                "status_code": res.status_code,
                "status": body.get("status", f"HTTP {res.status_code}"),
                "message": body.get("message") or body.get("error"),
                "latency_ms": lat,
                "booking_id": body.get("booking", {}).get("booking_id")
            }
        except Exception as exc:
            return {
                "client": user_name,
                "status_code": 503,
                "status": "ERROR",
                "message": str(exc),
                "latency_ms": round((time.time() - t0) * 1000, 2)
            }

    # Execute truly concurrent requests in thread pool
    with ThreadPoolExecutor(max_workers=concurrency_count) as executor:
        futures = [executor.submit(send_attempt, i) for i in range(concurrency_count)]
        for f in futures:
            results.append(f.result())

    # Count wins and conflicts
    wins = [r for r in results if r["status_code"] in (200, 201)]
    conflicts = [r for r in results if r["status_code"] == 409]

    log_event(
        f"Concurrency Test on {show_id}/{seat_id}: {len(wins)} succeeded, {len(conflicts)} rejected via mutual exclusion.",
        kind="good" if len(wins) == 1 else "warning",
        category="concurrency"
    )

    return jsonify(
        show_id=show_id,
        seat_id=seat_id,
        competing_requests=concurrency_count,
        successful_bookings=len(wins),
        rejected_conflicts=len(conflicts),
        results=results,
        explanation="Redis Lua script executed atomically on a single thread. The first request secured the mutex; subsequent requests encountered the lock and were safely rejected with HTTP 409 Conflict."
    )

@app.get("/cluster/telemetry")
def get_telemetry():
    with telemetry_lock:
        return jsonify(
            events=cluster_events[:40],
            routing_history=routing_history[:30],
            movie_a_count=sum(1 for r in routing_history if r.get("replica") == "Movie Server A"),
            movie_b_count=sum(1 for r in routing_history if r.get("replica") == "Movie Server B")
        )

if __name__ == "__main__":
    print("[gateway] Starting API Gateway on http://127.0.0.1:8000")
    app.run(host="127.0.0.1", port=8000, debug=False, threaded=True)
