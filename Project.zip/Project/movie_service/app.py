import os
import time
from flask import Flask, jsonify, request

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5001"))
INSTANCE = os.getenv("INSTANCE_NAME", f"movie-{PORT}")

START_TIME = time.time()
REQUEST_COUNT = 0
ERROR_COUNT = 0
SIMULATED_DOWN = False
LATENCY_SAMPLES = []

MOVIES = [
    {
        "id": "M101",
        "title": "Interstellar",
        "language": "English",
        "genre": "Sci-Fi / Adventure",
        "rating": 8.7,
        "duration": "2h 49m",
        "director": "Christopher Nolan",
        "cast": ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"],
        "synopsis": "When Earth becomes uninhabitable, a team of explorers embarks on humanity's greatest voyage through a wormhole to find a new home.",
        "poster": "/static/posters/interstellar.svg",
        "tag": "BLOCKBUSTER",
        "color": "#1B2A4A"
    },
    {
        "id": "M102",
        "title": "RRR",
        "language": "Telugu",
        "genre": "Action / Drama / Epic",
        "rating": 7.8,
        "duration": "3h 07m",
        "director": "S. S. Rajamouli",
        "cast": ["N. T. Rama Rao Jr.", "Ram Charan", "Alia Bhatt"],
        "synopsis": "A fearless revolutionary and an officer in the British force join hands in an epic struggle against colonial oppression in pre-independence India.",
        "poster": "/static/posters/rrr.svg",
        "tag": "OSCAR WINNER",
        "color": "#8B2500"
    },
    {
        "id": "M103",
        "title": "Dune: Part Two",
        "language": "English",
        "genre": "Sci-Fi / Adventure",
        "rating": 8.6,
        "duration": "2h 46m",
        "director": "Denis Villeneuve",
        "cast": ["Timothée Chalamet", "Zendaya", "Rebecca Ferguson"],
        "synopsis": "Paul Atreides unites with Chani and the Fremen while seeking vengeance against the conspirators who destroyed his family.",
        "poster": "/static/posters/dune2.svg",
        "tag": "IMAX EXPERIENCE",
        "color": "#B8860B"
    },
    {
        "id": "M104",
        "title": "Oppenheimer",
        "language": "English",
        "genre": "Biography / Drama / History",
        "rating": 8.9,
        "duration": "3h 00m",
        "director": "Christopher Nolan",
        "cast": ["Cillian Murphy", "Emily Blunt", "Matt Damon"],
        "synopsis": "The story of American scientist J. Robert Oppenheimer and his historical role in the development of the atomic bomb during World War II.",
        "poster": "/static/posters/oppenheimer.svg",
        "tag": "ACADEMY FAVORITE",
        "color": "#3B1408"
    },
    {
        "id": "M105",
        "title": "Spider-Man: Across the Spider-Verse",
        "language": "English",
        "genre": "Animation / Action / Sci-Fi",
        "rating": 8.6,
        "duration": "2h 20m",
        "director": "Joaquim Dos Santos, Kemp Powers",
        "cast": ["Shameik Moore", "Hailee Steinfeld", "Oscar Isaac"],
        "synopsis": "Miles Morales catapults across the Multiverse, where he encounters a team of Spider-People charged with protecting its very existence.",
        "poster": "/static/posters/spiderman.svg",
        "tag": "VISUAL MASTERPIECE",
        "color": "#990033"
    },
    {
        "id": "M106",
        "title": "Kantara: Chapter 1",
        "language": "Kannada",
        "genre": "Action / Fantasy / Mythological",
        "rating": 8.2,
        "duration": "2h 28m",
        "director": "Rishab Shetty",
        "cast": ["Rishab Shetty", "Sapthami Gowda", "Kishore"],
        "synopsis": "A human vs nature conflict interwoven with divine forest spirits, ancestral folklore, and generational justice.",
        "poster": "/static/posters/kantara.svg",
        "tag": "CULTURAL PHENOMENON",
        "color": "#2C402E"
    }
]

SHOWS = [
    {
        "id": "S201",
        "movie_id": "M101",
        "movie_title": "Interstellar",
        "theatre": "City Cinemas IMAX 70mm",
        "screen": "Screen 1 - Laser",
        "time": "18:30",
        "date": "Today",
        "sound": "Dolby Atmos 128-ch",
        "pricing": {"silver": 220, "gold": 280, "vip": 350, "recliner": 480}
    },
    {
        "id": "S202",
        "movie_id": "M102",
        "movie_title": "RRR",
        "theatre": "Grand Screens 4DX Dynamic",
        "screen": "Screen 2 - Motion Seats",
        "time": "20:00",
        "date": "Today",
        "sound": "Auro 11.1 3D",
        "pricing": {"silver": 250, "gold": 320, "vip": 400, "recliner": 550}
    },
    {
        "id": "S203",
        "movie_id": "M103",
        "movie_title": "Dune: Part Two",
        "theatre": "Metro Multiplex Premiere",
        "screen": "Screen 3 - 4K Dual Laser",
        "time": "21:15",
        "date": "Today",
        "sound": "Dolby Atmos Premium",
        "pricing": {"silver": 240, "gold": 300, "vip": 380, "recliner": 520}
    },
    {
        "id": "S204",
        "movie_id": "M104",
        "movie_title": "Oppenheimer",
        "theatre": "PVR Director's Cut Gold",
        "screen": "Auditorium 4 - Luxury Lounge",
        "time": "19:00",
        "date": "Today",
        "sound": "Dolby Surround 7.1",
        "pricing": {"silver": 300, "gold": 380, "vip": 450, "recliner": 600}
    },
    {
        "id": "S205",
        "movie_id": "M105",
        "movie_title": "Spider-Man: Across the Spider-Verse",
        "theatre": "Cinepolis Grand Arena",
        "screen": "Screen 5 - Dolby Cinema HDR",
        "time": "16:30",
        "date": "Today",
        "sound": "Dolby Vision + Atmos",
        "pricing": {"silver": 200, "gold": 260, "vip": 340, "recliner": 460}
    },
    {
        "id": "S206",
        "movie_id": "M106",
        "movie_title": "Kantara: Chapter 1",
        "theatre": "INOX Royale Palace",
        "screen": "Screen 6 - Insignia Hall",
        "time": "22:00",
        "date": "Today",
        "sound": "DTS:X Immersive",
        "pricing": {"silver": 220, "gold": 280, "vip": 360, "recliner": 500}
    }
]

@app.before_request
def check_simulated_crash():
    global ERROR_COUNT
    # Dev recovery endpoint must always remain callable
    if request.path.startswith("/dev/"):
        return None
    if SIMULATED_DOWN:
        ERROR_COUNT += 1
        return jsonify(
            error="Service temporarily unavailable (simulated fault injection)",
            status="DOWN",
            service=INSTANCE,
            port=PORT
        ), 503

@app.get("/health")
def health():
    if SIMULATED_DOWN:
        return jsonify(
            status="DOWN",
            service="movie-service",
            instance=INSTANCE,
            port=PORT,
            fault_injected=True,
            uptime_seconds=int(time.time() - START_TIME),
            request_count=REQUEST_COUNT
        ), 503

    avg_lat = round(sum(LATENCY_SAMPLES[-20:]) / len(LATENCY_SAMPLES[-20:]), 2) if LATENCY_SAMPLES else 1.2
    return jsonify(
        status="UP",
        service="movie-service",
        instance=INSTANCE,
        port=PORT,
        role="Catalog Replica",
        uptime_seconds=int(time.time() - START_TIME),
        request_count=REQUEST_COUNT,
        error_count=ERROR_COUNT,
        avg_latency_ms=avg_lat
    )

@app.get("/movies")
def movies():
    global REQUEST_COUNT
    t0 = time.time()
    REQUEST_COUNT += 1
    duration = (time.time() - t0) * 1000
    LATENCY_SAMPLES.append(duration)
    return jsonify(
        service=INSTANCE,
        port=PORT,
        movies=MOVIES,
        count=len(MOVIES),
        replica_id=INSTANCE
    )

@app.get("/movies/<movie_id>")
def movie_detail(movie_id):
    global REQUEST_COUNT
    REQUEST_COUNT += 1
    movie = next((m for m in MOVIES if m["id"] == movie_id), None)
    if not movie:
        return jsonify(error="Movie not found"), 404
    movie_shows = [s for s in SHOWS if s["movie_id"] == movie_id]
    return jsonify(service=INSTANCE, movie=movie, shows=movie_shows)

@app.get("/shows")
def shows():
    global REQUEST_COUNT
    t0 = time.time()
    REQUEST_COUNT += 1
    duration = (time.time() - t0) * 1000
    LATENCY_SAMPLES.append(duration)
    return jsonify(
        service=INSTANCE,
        port=PORT,
        shows=SHOWS,
        count=len(SHOWS)
    )

@app.get("/shows/<show_id>")
def show_detail(show_id):
    global REQUEST_COUNT
    REQUEST_COUNT += 1
    show = next((s for s in SHOWS if s["id"] == show_id), None)
    if not show:
        return jsonify(error="Show not found"), 404
    return jsonify(service=INSTANCE, show=show)

# Controlled development-only fault injection endpoints
@app.post("/dev/simulate_crash")
def simulate_crash():
    global SIMULATED_DOWN
    SIMULATED_DOWN = True
    return jsonify(
        action="crash",
        status="DOWN",
        service=INSTANCE,
        port=PORT,
        message=f"{INSTANCE} state set to DOWN. Health checks will return 503."
    ), 200

@app.post("/dev/simulate_recover")
def simulate_recover():
    global SIMULATED_DOWN
    SIMULATED_DOWN = False
    return jsonify(
        action="recover",
        status="UP",
        service=INSTANCE,
        port=PORT,
        message=f"{INSTANCE} recovered. Service is UP and accepting requests."
    ), 200

@app.get("/dev/metrics")
def metrics():
    return jsonify(
        instance=INSTANCE,
        port=PORT,
        uptime_seconds=int(time.time() - START_TIME),
        request_count=REQUEST_COUNT,
        error_count=ERROR_COUNT,
        simulated_down=SIMULATED_DOWN
    )

if __name__ == "__main__":
    print(f"[{INSTANCE}] Starting Movie Replica on http://127.0.0.1:{PORT}")
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
