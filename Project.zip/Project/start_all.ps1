# Windows PowerShell Script to launch all 5 BookMyShow Distributed Services
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  Starting BookMyShow Distributed Computing Cluster" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan

$pythonExe = ".\.venv\Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    $pythonExe = "python"
}

# 1. Movie Replica A (Port 5001)
Write-Host "[1/5] Launching Movie Server A (Port 5001)..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "`$env:PORT='5001'; `$env:INSTANCE_NAME='movie-A'; & '$pythonExe' -m movie_service.app"

# 2. Movie Replica B (Port 5004)
Write-Host "[2/5] Launching Movie Server B (Port 5004)..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "`$env:PORT='5004'; `$env:INSTANCE_NAME='movie-B'; & '$pythonExe' -m movie_service.app"

# 3. Booking Service (Port 5002)
Write-Host "[3/5] Launching Booking Service (Port 5002)..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$pythonExe' -m booking_service.app"

# 4. Seat Authority (Port 5003)
Write-Host "[4/5] Launching Seat Authority (Port 5003)..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$pythonExe' -m seat_service.app"

# 5. API Gateway (Port 8000)
Write-Host "[5/5] Launching API Gateway (Port 8000)..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "& '$pythonExe' -m gateway.app"

Start-Sleep -Seconds 2
Write-Host "`nAll 5 microservices launched in independent terminal processes!" -ForegroundColor Cyan
Write-Host "Opening Dashboard in default browser: http://127.0.0.1:8000/`n" -ForegroundColor Yellow
Start-Process "http://127.0.0.1:8000/"
