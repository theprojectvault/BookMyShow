import os

GATEWAY_PORT = int(os.getenv("GATEWAY_PORT", "8000"))
GATEWAY_URL = os.getenv("GATEWAY_URL", f"http://127.0.0.1:{GATEWAY_PORT}")

REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
BOOKING_SERVICE_URL = os.getenv("BOOKING_SERVICE_URL", "http://127.0.0.1:5002")
SEAT_SERVICE_URL = os.getenv("SEAT_SERVICE_URL", "http://127.0.0.1:5003")

MOVIE_REPLICAS = [
    os.getenv("MOVIE_SERVICE_A_URL", "http://127.0.0.1:5001"),
    os.getenv("MOVIE_SERVICE_B_URL", "http://127.0.0.1:5004"),
]

SERVICES = {
    "gateway": {"name": "API Gateway", "port": 8000, "url": GATEWAY_URL, "role": "Reverse Proxy, Load Balancer & Client Router"},
    "movie_A": {"name": "Movie Server A", "port": 5001, "url": MOVIE_REPLICAS[0], "role": "Movie Catalog Replica 1"},
    "movie_B": {"name": "Movie Server B", "port": 5004, "url": MOVIE_REPLICAS[1], "role": "Movie Catalog Replica 2"},
    "booking": {"name": "Booking Service", "port": 5002, "url": BOOKING_SERVICE_URL, "role": "Transaction Coordinator & Idempotency Manager"},
    "seats": {"name": "Seat Service", "port": 5003, "url": SEAT_SERVICE_URL, "role": "Seat Inventory Authority & Atomic Mutex Provider"},
}

REQUEST_TIMEOUT = float(os.getenv("REQUEST_TIMEOUT", "2.5"))
