/**
 * BookMyShow Distributed Computing 3D Topology Visualization
 * Engine: Three.js (r128) + OrbitControls
 * Color Palette: Ivory, Burgundy, Warm White, Subtle Gold, Soft Neutral Gray
 */

class DistributedTopology3D {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    if (!this.container) {
      console.error(`Container #${containerId} not found`);
      return;
    }

    this.options = options;
    this.nodes = {};
    this.conduits = [];
    this.activePackets = [];
    this.particleBursts = [];
    this.selectedNodeKey = null;
    this.hoveredNodeKey = null;
    this.clock = new THREE.Clock();
    this.isWebGLSupported = this.checkWebGL();

    if (!this.isWebGLSupported) {
      this.renderFallback();
      return;
    }

    this.initScene();
    this.initLights();
    this.initEnvironment();
    this.buildTopology();
    this.initInteraction();
    this.animate();
  }

  checkWebGL() {
    try {
      const canvas = document.createElement('canvas');
      return !!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
    } catch (e) {
      return false;
    }
  }

  renderFallback() {
    this.container.innerHTML = `
      <div class="webgl-fallback">
        <div class="fallback-card">
          <div class="fallback-icon">🌐</div>
          <h3>WebGL Hardware Acceleration Unavailable</h3>
          <p>Your browser is running in fallback mode. 2D Interactive Infrastructure Map is active below.</p>
        </div>
      </div>
    `;
  }

  initScene() {
    this.width = this.container.clientWidth || 800;
    this.height = this.container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xF8F6F0); // Luxury Ivory backdrop
    this.scene.fog = new THREE.FogExp2(0xF8F6F0, 0.015);

    this.camera = new THREE.PerspectiveCamera(45, this.width / this.height, 0.1, 1000);
    this.camera.position.set(0, 24, 34);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.container.appendChild(this.renderer.domElement);

    if (window.THREE && window.THREE.OrbitControls) {
      this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.06;
      this.controls.minDistance = 14;
      this.controls.maxDistance = 65;
      this.controls.maxPolarAngle = Math.PI / 2 - 0.05; // Keep above floor
      this.controls.target.set(0, 1.5, -1);
    }

    window.addEventListener('resize', () => this.onResize());
  }

  initLights() {
    // Warm luxury ambient illumination
    const ambient = new THREE.AmbientLight(0xFFFBF2, 0.95);
    this.scene.add(ambient);

    // Warm Gold Key Light
    const keyLight = new THREE.DirectionalLight(0xFDF8E2, 1.2);
    keyLight.position.set(15, 30, 20);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 5;
    keyLight.shadow.camera.far = 80;
    keyLight.shadow.camera.left = -25;
    keyLight.shadow.camera.right = 25;
    keyLight.shadow.camera.top = 25;
    keyLight.shadow.camera.bottom = -25;
    keyLight.shadow.bias = -0.0005;
    this.scene.add(keyLight);

    // Burgundy Rim Accent
    const rimLight = new THREE.DirectionalLight(0x8B1E3F, 0.7);
    rimLight.position.set(-20, 15, -20);
    this.scene.add(rimLight);

    // Subtle Gold Center Spotlight
    const centerSpot = new THREE.SpotLight(0xD4AF37, 1.4, 40, Math.PI / 4, 0.4, 1.5);
    centerSpot.position.set(0, 22, 10);
    centerSpot.target.position.set(0, 0, 0);
    this.scene.add(centerSpot);
    this.scene.add(centerSpot.target);
  }

  initEnvironment() {
    // Elegant Architectural Floor Grid
    const floorGeo = new THREE.PlaneGeometry(120, 120);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0xF3EFE6,
      roughness: 0.85,
      metalness: 0.1
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.05;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // Subtle Radial Concentric Rings
    const ringGroup = new THREE.Group();
    const ringMat = new THREE.LineBasicMaterial({ color: 0xDCD5C6, transparent: true, opacity: 0.6 });
    [8, 16, 24, 32, 42].forEach(radius => {
      const ringGeo = new THREE.BufferGeometry();
      const points = [];
      const segments = 64;
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * radius, 0.01, Math.sin(theta) * radius));
      }
      ringGeo.setFromPoints(points);
      const ring = new THREE.Line(ringGeo, ringMat);
      ringGroup.add(ring);
    });
    this.scene.add(ringGroup);
  }

  buildTopology() {
    // Node Specifications
    this.nodeDefs = {
      gateway: {
        id: "gateway",
        name: "API Gateway",
        subtitle: "Reverse Proxy & Load Balancer",
        port: 8000,
        position: new THREE.Vector3(0, 0, 9),
        color: 0xC59B27, // Subtle Gold
        shape: "hub",
        radius: 2.2,
        height: 3.2
      },
      movie_A: {
        id: "movie_A",
        name: "Movie Replica A",
        subtitle: "Catalog Node 1",
        port: 5001,
        position: new THREE.Vector3(-12, 0, -2),
        color: 0x8B1E3F, // Burgundy
        shape: "monolith",
        radius: 1.6,
        height: 2.8
      },
      movie_B: {
        id: "movie_B",
        name: "Movie Replica B",
        subtitle: "Catalog Node 2",
        port: 5004,
        position: new THREE.Vector3(-21, 0, -7),
        color: 0x8B1E3F, // Burgundy
        shape: "monolith",
        radius: 1.6,
        height: 2.8
      },
      booking: {
        id: "booking",
        name: "Booking Service",
        subtitle: "Transaction Coordinator",
        port: 5002,
        position: new THREE.Vector3(12, 0, 2),
        color: 0x2A6F97, // Cobalt Navy
        shape: "cube",
        radius: 1.7,
        height: 2.9
      },
      seats: {
        id: "seats",
        name: "Seat Authority",
        subtitle: "Inventory & Concurrency",
        port: 5003,
        position: new THREE.Vector3(18, 0, -9),
        color: 0x2D6A4F, // Emerald Sage
        shape: "cylinder",
        radius: 1.6,
        height: 3.0
      },
      redis: {
        id: "redis",
        name: "Redis State",
        subtitle: "Atomic Lua Mutex Store",
        port: 6379,
        position: new THREE.Vector3(18, -0.4, -9),
        color: 0xD90429, // Ruby Amber
        shape: "database",
        radius: 2.1,
        height: 0.8
      }
    };

    // Instantiate each 3D node
    Object.values(this.nodeDefs).forEach(def => {
      this.create3DNode(def);
    });

    // Connections (Spline conduits)
    this.createConduit("gateway", "movie_A", 0x8B1E3F);
    this.createConduit("gateway", "movie_B", 0x8B1E3F);
    this.createConduit("gateway", "booking", 0x2A6F97);
    this.createConduit("booking", "seats", 0x2D6A4F);
    this.createConduit("seats", "redis", 0xD90429, false); // Local bus
  }

  create3DNode(def) {
    const group = new THREE.Group();
    group.position.copy(def.position);
    group.userData = { ...def, status: "UP", requestCount: 0 };

    // Base pedestal disc
    const baseGeo = new THREE.CylinderGeometry(def.radius * 1.3, def.radius * 1.4, 0.35, 32);
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0xEDE8DC,
      roughness: 0.4,
      metalness: 0.2
    });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = 0.175;
    baseMesh.receiveShadow = true;
    baseMesh.castShadow = true;
    group.add(baseMesh);

    // Glowing status ring around base
    const ringGeo = new THREE.TorusGeometry(def.radius * 1.35, 0.08, 16, 48);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x10B981, // Healthy green default
      transparent: true,
      opacity: 0.85
    });
    const statusRing = new THREE.Mesh(ringGeo, ringMat);
    statusRing.rotation.x = Math.PI / 2;
    statusRing.position.y = 0.36;
    group.add(statusRing);
    group.userData.statusRing = statusRing;

    // Core Geometry based on node shape
    let coreGeo, coreMat;
    coreMat = new THREE.MeshStandardMaterial({
      color: def.color,
      roughness: 0.25,
      metalness: 0.3,
      emissive: def.color,
      emissiveIntensity: 0.15
    });

    if (def.shape === "hub") {
      // API Gateway: Hexagonal faceted column
      coreGeo = new THREE.CylinderGeometry(def.radius, def.radius * 1.1, def.height, 6);
    } else if (def.shape === "monolith") {
      // Movie Replicas: Sleek rounded monolith
      coreGeo = new THREE.CylinderGeometry(def.radius, def.radius, def.height, 24);
    } else if (def.shape === "cube") {
      // Booking Service: Faceted Chamfered Box
      coreGeo = new THREE.BoxGeometry(def.radius * 1.8, def.height, def.radius * 1.8);
    } else if (def.shape === "database") {
      // Redis: Wide disk tier
      coreGeo = new THREE.CylinderGeometry(def.radius * 1.2, def.radius * 1.2, def.height, 32);
    } else {
      // Seat Authority: High cylindrical tower
      coreGeo = new THREE.CylinderGeometry(def.radius, def.radius, def.height, 32);
    }

    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    coreMesh.position.y = def.height / 2 + 0.35;
    coreMesh.castShadow = true;
    coreMesh.receiveShadow = true;
    group.add(coreMesh);
    group.userData.coreMesh = coreMesh;

    // Glowing energy band around core
    const bandGeo = new THREE.CylinderGeometry(def.radius * 1.03, def.radius * 1.03, 0.4, 32, 1, true);
    const bandMat = new THREE.MeshBasicMaterial({
      color: 0xFFFFFF,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide
    });
    const bandMesh = new THREE.Mesh(bandGeo, bandMat);
    bandMesh.position.y = coreMesh.position.y;
    group.add(bandMesh);

    // Floating Holographic Halo Ring
    const haloGeo = new THREE.TorusGeometry(def.radius * 1.15, 0.05, 12, 36);
    const haloMat = new THREE.MeshBasicMaterial({
      color: def.color,
      transparent: true,
      opacity: 0.7
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    haloMesh.rotation.x = Math.PI / 2;
    haloMesh.position.y = def.height + 0.8;
    group.add(haloMesh);
    group.userData.haloMesh = haloMesh;

    // Beacon Crown Sphere
    const beaconGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xFFFBF0 });
    const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    beaconMesh.position.y = def.height + 0.8;
    group.add(beaconMesh);
    group.userData.beaconMesh = beaconMesh;

    // Floating 2D Billboard Canvas Label
    const spriteLabel = this.createLabelSprite(def.name, `:${def.port}`);
    spriteLabel.position.y = def.height + 2.2;
    group.add(spriteLabel);
    group.userData.spriteLabel = spriteLabel;

    this.scene.add(group);
    this.nodes[def.id] = group;
  }

  createLabelSprite(title, portText) {
    const canvas = document.createElement('canvas');
    canvas.width = 384;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');

    // Clean semi-translucent pill badge
    ctx.fillStyle = 'rgba(255, 253, 249, 0.92)';
    this.roundRect(ctx, 16, 16, 352, 96, 24);
    ctx.fill();

    // Border
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.5)';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Text: Title
    ctx.font = 'bold 30px "Outfit", "Inter", sans-serif';
    ctx.fillStyle = '#1F2421';
    ctx.textAlign = 'center';
    ctx.fillText(title, 192, 58);

    // Text: Port / Protocol
    ctx.font = '600 20px "JetBrains Mono", monospace';
    ctx.fillStyle = '#800020';
    ctx.fillText(portText, 192, 92);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(6.2, 2.1, 1);
    return sprite;
  }

  roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  createConduit(fromId, toId, colorHex, arcAbove = true) {
    const fromNode = this.nodes[fromId];
    const toNode = this.nodes[toId];
    if (!fromNode || !toNode) return;

    const p1 = fromNode.position.clone().add(new THREE.Vector3(0, 1.8, 0));
    const p2 = toNode.position.clone().add(new THREE.Vector3(0, 1.8, 0));

    // Midpoint curved arc
    const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
    if (arcAbove) {
      mid.y += Math.min(p1.distanceTo(p2) * 0.22, 4.2);
    }

    const curve = new THREE.CatmullRomCurve3([p1, mid, p2]);
    const tubeGeo = new THREE.TubeGeometry(curve, 48, 0.12, 12, false);
    const tubeMat = new THREE.MeshStandardMaterial({
      color: 0xE2DDD2,
      roughness: 0.3,
      metalness: 0.4,
      transparent: true,
      opacity: 0.75
    });

    const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
    tubeMesh.receiveShadow = true;
    this.scene.add(tubeMesh);

    // Glowing core fiber line
    const points = curve.getPoints(60);
    const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
    const lineMat = new THREE.LineDashedMaterial({
      color: colorHex,
      dashSize: 0.8,
      gapSize: 0.5,
      transparent: true,
      opacity: 0.85
    });
    const lineMesh = new THREE.Line(lineGeo, lineMat);
    lineMesh.computeLineDistances();
    this.scene.add(lineMesh);

    this.conduits.push({
      fromId,
      toId,
      curve,
      tubeMesh,
      lineMesh,
      colorHex
    });
  }

  findConduit(fromId, toId) {
    return this.conduits.find(c => 
      (c.fromId === fromId && c.toId === toId) ||
      (c.fromId === toId && c.toId === fromId)
    );
  }

  /**
   * Dispatches an animated 3D packet along a conduit between services
   */
  dispatchPacket(options = {}) {
    const {
      from = "gateway",
      to = "movie_A",
      color = 0xD4AF37,
      duration = 0.9,
      size = 0.42,
      reverse = false,
      isFailover = false,
      rerouteTo = null,
      onComplete = null
    } = options;

    const conduit = this.findConduit(from, to);
    if (!conduit) {
      console.warn(`No conduit found between ${from} and ${to}`);
      if (onComplete) onComplete();
      return;
    }

    // Packet Sphere Mesh with glowing aura
    const packetGroup = new THREE.Group();
    const sphereGeo = new THREE.SphereGeometry(size, 16, 16);
    const sphereMat = new THREE.MeshBasicMaterial({ color: color });
    const sphere = new THREE.Mesh(sphereGeo, sphereMat);
    packetGroup.add(sphere);

    // Aura Halo
    const auraGeo = new THREE.SphereGeometry(size * 1.8, 12, 12);
    const auraMat = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.45
    });
    const aura = new THREE.Mesh(auraGeo, auraMat);
    packetGroup.add(aura);

    this.scene.add(packetGroup);

    this.activePackets.push({
      mesh: packetGroup,
      conduit: conduit,
      from: from,
      to: to,
      curve: conduit.curve,
      reverse: reverse,
      progress: 0,
      speed: 1 / Math.max(duration, 0.2),
      isFailover: isFailover,
      rerouteTo: rerouteTo,
      hasRerouted: false,
      color: color,
      onComplete: onComplete
    });

    // Notify node busy state
    this.pulseNode(from, 0.4);
  }

  /**
   * Pulses node scale and halo when interacting
   */
  pulseNode(nodeKey, intensity = 1.0) {
    const node = this.nodes[nodeKey];
    if (!node) return;
    node.userData.pulseEnergy = 1.0 * intensity;
  }

  /**
   * Creates a shockwave particle burst at destination
   */
  triggerArrivalBurst(position, colorHex) {
    const ringGeo = new THREE.RingGeometry(0.3, 0.6, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity: 1.0,
      side: THREE.DoubleSide
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.copy(position).add(new THREE.Vector3(0, 1.8, 0));
    this.scene.add(ring);

    this.particleBursts.push({
      mesh: ring,
      scale: 1,
      opacity: 1.0,
      maxScale: 4.8,
      fadeSpeed: 2.2
    });
  }

  /**
   * Updates a node's visual state based on live backend health
   */
  updateNodeState(nodeKey, status, details = {}) {
    const node = this.nodes[nodeKey];
    if (!node) return;

    node.userData.status = status;
    node.userData.details = details;
    if (details.request_count !== undefined) {
      node.userData.requestCount = details.request_count;
    }

    const isUp = status === "UP";
    const statusColor = isUp ? 0x10B981 : 0xEF4444; // Green vs Crimson Red

    if (node.userData.statusRing) {
      node.userData.statusRing.material.color.setHex(statusColor);
    }
    if (node.userData.beaconMesh) {
      node.userData.beaconMesh.material.color.setHex(isUp ? 0xFFFFFF : 0xFF2A2A);
    }

    // Monolith Core Emissive
    if (node.userData.coreMesh) {
      node.userData.coreMesh.material.emissive.setHex(isUp ? node.userData.color : 0x990000);
      node.userData.coreMesh.material.emissiveIntensity = isUp ? 0.2 : 0.65;
    }

    // Red Alarm Flickering on Down
    node.userData.isDown = !isUp;
  }

  initInteraction() {
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();

    const canvas = this.renderer.domElement;

    canvas.addEventListener('mousemove', (event) => {
      const rect = canvas.getBoundingClientRect();
      this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      this.checkHover();
    });

    canvas.addEventListener('click', (event) => {
      const rect = canvas.getBoundingClientRect();
      this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      this.checkClick();
    });
  }

  checkHover() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const interactables = Object.values(this.nodes).map(n => n.userData.coreMesh).filter(Boolean);
    const intersects = this.raycaster.intersectObjects(interactables);

    if (intersects.length > 0) {
      const hit = intersects[0].object.parent;
      if (hit && hit.userData.id) {
        this.container.style.cursor = 'pointer';
        if (this.hoveredNodeKey !== hit.userData.id) {
          this.hoveredNodeKey = hit.userData.id;
          if (this.options.onNodeHover) {
            this.options.onNodeHover(hit.userData);
          }
        }
        return;
      }
    }

    this.container.style.cursor = 'default';
    if (this.hoveredNodeKey !== null) {
      this.hoveredNodeKey = null;
      if (this.options.onNodeHover) {
        this.options.onNodeHover(null);
      }
    }
  }

  checkClick() {
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const interactables = Object.values(this.nodes).map(n => n.userData.coreMesh).filter(Boolean);
    const intersects = this.raycaster.intersectObjects(interactables);

    if (intersects.length > 0) {
      const hit = intersects[0].object.parent;
      if (hit && hit.userData.id) {
        this.selectNode(hit.userData.id);
      }
    }
  }

  selectNode(nodeKey) {
    this.selectedNodeKey = nodeKey;
    const node = this.nodes[nodeKey];
    if (!node) return;

    this.pulseNode(nodeKey, 1.8);

    if (this.options.onNodeSelect) {
      this.options.onNodeSelect(node.userData);
    }
  }

  setCameraPreset(preset) {
    if (!this.controls) return;
    const targets = {
      overview: { pos: new THREE.Vector3(0, 24, 34), target: new THREE.Vector3(0, 1.5, -1) },
      loadBalancer: { pos: new THREE.Vector3(-14, 15, 18), target: new THREE.Vector3(-12, 1.5, -3) },
      bookingFlow: { pos: new THREE.Vector3(14, 15, 20), target: new THREE.Vector3(14, 1.5, -3) },
      reset: { pos: new THREE.Vector3(0, 24, 34), target: new THREE.Vector3(0, 1.5, -1) }
    };

    const cfg = targets[preset] || targets.overview;
    this.smoothCameraTo(cfg.pos, cfg.target);
  }

  smoothCameraTo(endPos, endTarget) {
    const startPos = this.camera.position.clone();
    const startTarget = this.controls.target.clone();
    let t = 0;
    const step = () => {
      t += 0.045;
      if (t < 1) {
        this.camera.position.lerpVectors(startPos, endPos, t);
        this.controls.target.lerpVectors(startTarget, endTarget, t);
        requestAnimationFrame(step);
      } else {
        this.camera.position.copy(endPos);
        this.controls.target.copy(endTarget);
      }
    };
    step();
  }

  onResize() {
    if (!this.container || !this.renderer) return;
    this.width = this.container.clientWidth;
    this.height = this.container.clientHeight;
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(this.width, this.height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    const delta = this.clock.getDelta();
    const time = this.clock.getElapsedTime();

    if (this.controls) {
      this.controls.update();
    }

    // Animate Nodes & Floating Halos
    Object.values(this.nodes).forEach(node => {
      if (node.userData.haloMesh) {
        node.userData.haloMesh.rotation.z += 0.015;
      }

      // Energy pulse decay
      if (node.userData.pulseEnergy) {
        node.userData.pulseEnergy -= delta * 1.8;
        if (node.userData.pulseEnergy < 0) node.userData.pulseEnergy = 0;
        const scale = 1 + node.userData.pulseEnergy * 0.12;
        node.scale.set(scale, scale, scale);
      }

      // Warning flicker if down
      if (node.userData.isDown && node.userData.beaconMesh) {
        const flicker = Math.sin(time * 12) > 0 ? 0xFF0000 : 0x440000;
        node.userData.beaconMesh.material.color.setHex(flicker);
      }
    });

    // Animate Conduits (Dash Flow)
    this.conduits.forEach(c => {
      if (c.lineMesh && c.lineMesh.material) {
        c.lineMesh.material.dashSize = 0.8 + Math.sin(time * 3) * 0.2;
      }
    });

    // Animate 3D Data Packets
    for (let i = this.activePackets.length - 1; i >= 0; i--) {
      const pkt = this.activePackets[i];
      pkt.progress += delta * pkt.speed;

      // Failover rerouting simulation
      if (pkt.isFailover && pkt.rerouteTo && !pkt.hasRerouted && pkt.progress >= 0.5) {
        pkt.hasRerouted = true;
        // Spark red warning
        pkt.mesh.children[0].material.color.setHex(0xEF4444);
        this.triggerArrivalBurst(pkt.mesh.position, 0xEF4444);

        // Switch conduit to backup replica
        const newConduit = this.findConduit(pkt.from, pkt.rerouteTo);
        if (newConduit) {
          pkt.conduit = newConduit;
          pkt.curve = newConduit.curve;
          pkt.to = pkt.rerouteTo;
          pkt.progress = 0.45; // Pick up on the new path
        }
      }

      if (pkt.progress >= 1.0) {
        // Packet arrived at destination!
        const destNode = this.nodes[pkt.to];
        if (destNode) {
          this.pulseNode(pkt.to, 1.2);
          this.triggerArrivalBurst(destNode.position, pkt.color);
        }

        if (pkt.onComplete) {
          pkt.onComplete();
        }

        this.scene.remove(pkt.mesh);
        this.activePackets.splice(i, 1);
      } else {
        const u = pkt.reverse ? 1 - pkt.progress : pkt.progress;
        const pt = pkt.curve.getPoint(Math.max(0, Math.min(1, u)));
        pkt.mesh.position.copy(pt);
      }
    }

    // Animate Arrival Shockwaves
    for (let j = this.particleBursts.length - 1; j >= 0; j--) {
      const burst = this.particleBursts[j];
      burst.scale += delta * burst.fadeSpeed * 3;
      burst.opacity -= delta * burst.fadeSpeed;
      burst.mesh.scale.set(burst.scale, burst.scale, burst.scale);
      burst.mesh.material.opacity = Math.max(0, burst.opacity);

      if (burst.opacity <= 0) {
        this.scene.remove(burst.mesh);
        this.particleBursts.splice(j, 1);
      }
    }

    this.renderer.render(this.scene, this.camera);
  }
}

window.DistributedTopology3D = DistributedTopology3D;
