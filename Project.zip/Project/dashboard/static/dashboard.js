/**
 * BookMyShow Distributed Computing Demonstrator
 * Frontend Logic, State Management & 3D Synchronization
 */

const $ = (id) => document.getElementById(id);

// Global State
let topology3D = null;
let clusterState = {
  gateway: "UP",
  services: {},
  servicesOnline: 0,
  redisStatus: "UP"
};

let currentTab = "topology";
let moviesList = [];
let showsList = [];
let selectedMovie = null;
let selectedShow = null;
let selectedSeat = null;
let seatDataMap = new Map();
let bookingHistory = [];
let routingStats = { aCount: 0, bCount: 0, total: 0 };
let eventsList = [];

// ==========================================================================
// Initialization
// ==========================================================================

document.addEventListener("DOMContentLoaded", () => {
  initNavigation();
  init3DScene();
  bindLabActions();
  bindCinemaActions();
  bindInspectorControls();

  // Initial Data Fetch
  refreshClusterHealth();
  fetchMoviesAndShows();
  fetchBookingHistory();

  // Periodic Telemetry Poll (every 4 seconds)
  setInterval(() => {
    refreshClusterHealth(false);
    fetchTelemetry();
  }, 4000);
});

// ==========================================================================
// Navigation & Tab Switching
// ==========================================================================

function initNavigation() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      switchTab(target);
    });
  });
}

function switchTab(tabId) {
  currentTab = tabId;

  document.querySelectorAll(".tab-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === tabId);
  });

  document.querySelectorAll(".tab-content").forEach((c) => {
    c.classList.toggle("active", c.id === `tab-${tabId}`);
  });

  // Re-render / resize 3D canvas if switching back to topology
  if (tabId === "topology" && topology3D) {
    setTimeout(() => topology3D.onResize(), 60);
  }
}

// ==========================================================================
// 3D Scene Initialization
// ==========================================================================

function init3DScene() {
  const container = $("canvas3d-container");
  if (!container) return;

  topology3D = new DistributedTopology3D("canvas3d-container", {
    onNodeSelect: (nodeData) => {
      displayNodeInspector(nodeData);
    },
    onNodeHover: (nodeData) => {
      if (nodeData) {
        $("inspectorHint").textContent = `Hovering: ${nodeData.name} (Port ${nodeData.port})`;
      } else {
        $("inspectorHint").textContent = "Click any 3D node to inspect real-time metrics";
      }
    }
  });

  // Camera preset buttons
  document.querySelectorAll("[data-preset]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (topology3D) topology3D.setCameraPreset(btn.dataset.preset);
    });
  });
}

function displayNodeInspector(data) {
  if (!data) return;
  $("inspectorTitle").textContent = data.name || "Service Node";
  $("inspectorPort").textContent = `PORT :${data.port || "8000"}`;
  $("inspectorRole").textContent = data.subtitle || data.role || "Distributed Component";
  $("inspectorStatus").innerHTML = `<span class="legend-swatch ${data.status === "UP" ? "up" : "down"}"></span> ${data.status}`;
  $("inspectorRequests").textContent = data.requestCount || 0;
  $("inspectorUptime").textContent = data.details?.uptime_seconds ? `${data.details.uptime_seconds}s` : "Online";

  const btn = $("inspectorToggleBtn");
  if (data.id === "gateway" || data.id === "redis") {
    btn.style.display = "none";
  } else {
    btn.style.display = "block";
    const isUp = data.status === "UP";
    btn.textContent = isUp ? `Inject Fault (Stop ${data.name})` : `Recover (${data.name})`;
    btn.className = `btn ${isUp ? "btn-outline" : "btn-gold"}`;
    btn.onclick = () => toggleServiceFault(data.id, isUp ? "crash" : "recover");
  }
}

// ==========================================================================
// Cluster Health & Observability Polling
// ==========================================================================

async function refreshClusterHealth(showFeedback = true) {
  if (showFeedback && $("refreshHealthBtn")) {
    $("refreshHealthBtn").disabled = true;
  }

  try {
    const res = await fetch("/cluster/status");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    clusterState = data;

    // Update Topbar Stats
    $("onlineCount").innerHTML = `${data.services_online}<small> / ${data.total_services}</small>`;
    $("gatewayState").innerHTML = `<span class="legend-swatch up"></span> UP`;
    $("redisState").innerHTML = `<span class="legend-swatch ${data.redis_status === "UP" ? "up" : "gold"}"></span> ${data.redis_status === "UP" ? "Redis Live" : "Memory Mutex"}`;

    // Update 3D nodes
    if (topology3D) {
      topology3D.updateNodeState("gateway", "UP", { role: "Load Balancer", request_count: routingStats.total });
      topology3D.updateNodeState("redis", data.redis_status === "UP" ? "UP" : "UP", { role: "Atomic Key Store" });

      if (data.services) {
        Object.entries(data.services).forEach(([key, s]) => {
          topology3D.updateNodeState(key, s.status, s.details || {});
        });
      }
    }

    // Update Fault Lab cards
    updateFaultLabCards(data.services);

    if (showFeedback) {
      toast("Cluster health verified across all 5 processes.");
    }
  } catch (err) {
    $("gatewayState").innerHTML = `<span class="legend-swatch down"></span> DOWN`;
    if (topology3D) topology3D.updateNodeState("gateway", "DOWN");
    if (showFeedback) toast("Gateway offline. Start gateway/app.py on port 8000.");
  } finally {
    if (showFeedback && $("refreshHealthBtn")) {
      $("refreshHealthBtn").disabled = false;
    }
  }
}

function updateFaultLabCards(services) {
  if (!services) return;
  const mapping = {
    movie_A: "cardMovieA",
    movie_B: "cardMovieB",
    booking: "cardBooking",
    seats: "cardSeats"
  };

  Object.entries(mapping).forEach(([key, cardId]) => {
    const el = $(cardId);
    if (!el) return;
    const s = services[key];
    const isUp = s && s.status === "UP";
    el.classList.toggle("down", !isUp);

    const statusBadge = el.querySelector(".status-badge");
    if (statusBadge) {
      statusBadge.className = `status-badge ${isUp ? "up" : "down"}`;
      statusBadge.textContent = isUp ? "HEALTHY : UP" : "FAILED : DOWN";
    }

    const toggleBtn = el.querySelector(".toggle-btn");
    if (toggleBtn) {
      toggleBtn.textContent = isUp ? "Inject Failure" : "Restore Node";
      toggleBtn.className = `btn btn-sm ${isUp ? "btn-outline" : "btn-gold"} toggle-btn`;
      toggleBtn.onclick = () => toggleServiceFault(key, isUp ? "crash" : "recover");
    }
  });
}

async function toggleServiceFault(serviceKey, action) {
  try {
    toast(`Sending ${action.toUpperCase()} signal to ${serviceKey}...`);
    const res = await fetch(`/cluster/control/${serviceKey}/${action}`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Action failed");

    toast(data.message || `Service ${serviceKey} is now ${action === "crash" ? "DOWN" : "UP"}`);
    await refreshClusterHealth(false);

    // If inspected node is this service, refresh inspector
    if (topology3D && topology3D.selectedNodeKey === serviceKey) {
      displayNodeInspector(topology3D.nodes[serviceKey]?.userData);
    }
  } catch (err) {
    toast(`Fault injection error: ${err.message}`);
  }
}

// ==========================================================================
// Load Balancing Laboratory
// ==========================================================================

function bindLabActions() {
  $("btnSendMovie1x")?.addEventListener("click", () => sendMovieRequest(1));
  $("btnSendMovie5x")?.addEventListener("click", () => sendMovieRequest(5));
  $("btnSendMovie10x")?.addEventListener("click", () => sendMovieRequest(10));

  $("btnRefreshHealth")?.addEventListener("click", () => refreshClusterHealth(true));
  $("refreshHealthBtn")?.addEventListener("click", () => refreshClusterHealth(true));

  // Concurrency & Idempotency Tests
  $("btnRunConcurrencyRace")?.addEventListener("click", runConcurrencyRaceTest);
  $("btnRunIdempotencyTest")?.addEventListener("click", runIdempotencyProofTest);

  // Seat map reset
  $("btnResetSeatMap")?.addEventListener("click", resetCurrentShowSeats);
}

async function sendMovieRequest(batchCount = 1) {
  const resultBox = $("lbResultMain");
  const detailBox = $("lbResultDetail");
  resultBox.textContent = `Dispatching ${batchCount} request(s) via API Gateway...`;

  for (let i = 0; i < batchCount; i++) {
    const t0 = performance.now();
    try {
      const res = await fetch("/movies");
      const elapsed = Math.round(performance.now() - t0);
      const data = await res.json();

      if (res.ok) {
        const replicaName = data.replica_name || data.service || "Movie Replica";
        const replicaKey = replicaName.includes("A") ? "movie_A" : "movie_B";
        const isFailover = !!data.failover_triggered;

        // Animate 3D Packet
        if (topology3D) {
          topology3D.dispatchPacket({
            from: "gateway",
            to: isFailover ? (replicaKey === "movie_A" ? "movie_B" : "movie_A") : replicaKey,
            color: isFailover ? 0xEF4444 : 0xD4AF37,
            isFailover: isFailover,
            rerouteTo: isFailover ? replicaKey : null
          });
        }

        resultBox.textContent = `Handled by ${replicaName} (${elapsed}ms)`;
        detailBox.innerHTML = `
          <strong>Gateway Routing:</strong> ${data.routed_to}<br>
          <strong>Status:</strong> HTTP 200 OK | <strong>Attempts:</strong> ${data.attempts || 1}<br>
          ${isFailover ? `<span style="color: #EF4444; font-weight: 700;">⚠️ Automatic Failover Triggered: Primary replica was down, seamless reroute to ${replicaName} succeeded!</span>` : `<span style="color: #10B981;">✓ Standard Round-Robin Distribution</span>`}
        `;

        if (replicaName.includes("A")) routingStats.aCount++;
        else routingStats.bCount++;
        routingStats.total++;
        updateLbDistributionUI();

        logLocalEvent(`GET /movies routed to ${replicaName} (${elapsed}ms)`, isFailover ? "warning" : "good");
      } else {
        resultBox.textContent = "Request Failed (HTTP 503)";
        detailBox.textContent = data.error || "All replicas are offline";
        logLocalEvent(`GET /movies failed: All replicas unreachable`, "bad");

        if (topology3D) {
          topology3D.dispatchPacket({
            from: "gateway",
            to: "movie_A",
            color: 0xEF4444
          });
        }
      }
    } catch (e) {
      resultBox.textContent = "Gateway Connection Refused";
      detailBox.textContent = e.message;
    }

    if (batchCount > 1) await new Promise((r) => setTimeout(r, 220));
  }
}

function updateLbDistributionUI() {
  $("lbTotalCount").textContent = routingStats.total;
  $("lbReplicaACount").textContent = routingStats.aCount;
  $("lbReplicaBCount").textContent = routingStats.bCount;

  const total = routingStats.total || 1;
  const pctA = Math.round((routingStats.aCount / total) * 100);
  const pctB = Math.round((routingStats.bCount / total) * 100);

  if ($("lbReplicaABar")) $("lbReplicaABar").style.width = `${pctA}%`;
  if ($("lbReplicaBBar")) $("lbReplicaBBar").style.width = `${pctB}%`;
}

// ==========================================================================
// Concurrency & Consistency Laboratory
// ==========================================================================

async function runConcurrencyRaceTest() {
  const showId = selectedShow?.id || "S201";
  const targetSeat = "B4"; // Hotly contested seat
  const outputBox = $("concurrencyResultBox");
  outputBox.innerHTML = `<div class="result-main">Executing concurrent race test on ${showId} - Seat ${targetSeat}...</div>`;

  // Animate multiple 3D packets firing in parallel
  if (topology3D) {
    topology3D.dispatchPacket({ from: "gateway", to: "booking", color: 0x8B1E3F });
    setTimeout(() => topology3D.dispatchPacket({ from: "booking", to: "seats", color: 0x2D6A4F }), 150);
  }

  try {
    const res = await fetch("/cluster/concurrency_test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ show_id: showId, seat_id: targetSeat, count: 3 })
    });
    const data = await res.json();

    let html = `
      <div style="margin-bottom: 12px;">
        <h4 style="color: var(--burgundy-primary); font-size: 1.1rem; margin-bottom: 4px;">Atomic Mutex Concurrency Verification</h4>
        <p style="font-size: 0.86rem; color: var(--text-secondary);">${data.explanation}</p>
      </div>
      <div style="display: grid; gap: 8px;">
    `;

    data.results.forEach((r, idx) => {
      const isWin = r.status_code === 201;
      html += `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 14px; border-radius: var(--radius-sm); background: ${isWin ? "var(--status-up-subtle)" : "var(--status-down-subtle)"}; border: 1px solid ${isWin ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"};">
          <div>
            <strong>${r.client}</strong> (${r.latency_ms}ms)
            <div style="font-size: 0.78rem; color: var(--text-secondary);">${r.message || r.status}</div>
          </div>
          <span class="badge ${isWin ? "up" : "down"}" style="font-weight: 700; font-size: 0.82rem;">
            HTTP ${r.status_code} : ${isWin ? "201 CREATED (WON LOCK)" : "409 CONFLICT (REJECTED)"}
          </span>
        </div>
      `;
    });

    html += `</div>`;
    outputBox.innerHTML = html;

    toast("Concurrency test completed. Check results table.");
    if (selectedShow) loadSeatsForShow(selectedShow.id);
  } catch (err) {
    outputBox.innerHTML = `<div class="result-main" style="color: var(--status-down);">Test Failed: ${err.message}</div>`;
  }
}

async function runIdempotencyProofTest() {
  const showId = selectedShow?.id || "S201";
  const seatId = "C7";
  const fixedIdempotencyKey = `idempotency-proof-key-${Date.now()}`;
  const outputBox = $("concurrencyResultBox");

  outputBox.innerHTML = `<div class="result-main">Executing Idempotency Test (sending 2 identical requests with key: ${fixedIdempotencyKey})...</div>`;

  try {
    // 1st request
    const res1 = await fetch("/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Idempotency-Key": fixedIdempotencyKey },
      body: JSON.stringify({
        show_id: showId,
        seat_id: seatId,
        customer_name: "Idempotency Auditor",
        idempotency_key: fixedIdempotencyKey
      })
    });
    const data1 = await res1.json();

    // 2nd request with EXACT same key
    const res2 = await fetch("/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Idempotency-Key": fixedIdempotencyKey },
      body: JSON.stringify({
        show_id: showId,
        seat_id: seatId,
        customer_name: "Idempotency Auditor",
        idempotency_key: fixedIdempotencyKey
      })
    });
    const data2 = await res2.json();

    outputBox.innerHTML = `
      <div style="margin-bottom: 12px;">
        <h4 style="color: var(--burgundy-primary); font-size: 1.1rem; margin-bottom: 4px;">Idempotency Guarantee Demonstration</h4>
        <p style="font-size: 0.86rem; color: var(--text-secondary);">Distributed systems must tolerate network retries without charging the user twice or reserving two seats.</p>
      </div>
      <div style="display: grid; gap: 8px;">
        <div style="padding: 10px 14px; border-radius: var(--radius-sm); background: var(--status-up-subtle); border: 1px solid rgba(16,185,129,0.3);">
          <strong>Request 1 (Initial Booking):</strong> HTTP ${res1.status} ${data1.status} - Booking ID: ${data1.booking?.booking_id || "N/A"}
        </div>
        <div style="padding: 10px 14px; border-radius: var(--radius-sm); background: var(--gold-subtle); border: 1px solid rgba(197,155,39,0.3);">
          <strong>Request 2 (Duplicate Retry):</strong> HTTP ${res2.status} ${data2.status} - Returned Cached Booking ID: ${data2.booking?.booking_id || "N/A"}
          <div style="font-size: 0.8rem; margin-top: 4px; color: var(--text-secondary);">Message: ${data2.message}</div>
        </div>
      </div>
    `;

    toast("Idempotency test completed successfully!");
    if (selectedShow) loadSeatsForShow(selectedShow.id);
  } catch (err) {
    outputBox.innerHTML = `<div class="result-main" style="color: var(--status-down);">Idempotency test error: ${err.message}</div>`;
  }
}

// ==========================================================================
// Cinema Booking Experience
// ==========================================================================

function bindCinemaActions() {
  $("btnConfirmBooking")?.addEventListener("click", handleBookingSubmit);
  $("btnCloseTicketModal")?.addEventListener("click", () => {
    $("ticketModal")?.classList.remove("show");
  });
}

async function fetchMoviesAndShows() {
  try {
    const [resMovies, resShows] = await Promise.all([
      fetch("/movies"),
      fetch("/shows")
    ]);

    if (!resMovies.ok || !resShows.ok) return;

    const dataMovies = await resMovies.json();
    const dataShows = await resShows.json();

    moviesList = dataMovies.movies || [];
    showsList = dataShows.shows || [];

    renderMovieCards();
  } catch (e) {
    console.error("Failed to load cinema data:", e);
  }
}

function renderMovieCards() {
  const container = $("moviesGrid");
  if (!container) return;

  container.innerHTML = moviesList.map((m, idx) => `
    <div class="movie-card ${idx === 0 ? "selected" : ""}" data-movie-id="${m.id}">
      <div class="poster-wrap">
        <img src="${m.poster}" alt="${m.title}" class="poster-img" loading="lazy">
        <span class="movie-card-badge">${m.tag || "PREMIERE"}</span>
      </div>
      <div class="movie-card-info">
        <div>
          <h4 class="movie-title">${m.title}</h4>
          <div class="movie-meta">
            <span class="movie-rating">★ ${m.rating}</span>
            <span>•</span>
            <span>${m.duration}</span>
          </div>
        </div>
        <div style="font-size: 0.76rem; color: var(--text-secondary); margin-bottom: 8px;">
          ${m.genre}
        </div>
        <button class="btn btn-outline" style="width: 100%; padding: 8px 12px; font-size: 0.82rem;">Select Shows</button>
      </div>
    </div>
  `).join("");

  // Bind click
  container.querySelectorAll(".movie-card").forEach((card) => {
    card.addEventListener("click", () => {
      const mid = card.dataset.movieId;
      selectMovie(mid);
    });
  });

  if (moviesList.length > 0) {
    selectMovie(moviesList[0].id);
  }
}

function selectMovie(movieId) {
  selectedMovie = moviesList.find((m) => m.id === movieId);
  if (!selectedMovie) return;

  document.querySelectorAll(".movie-card").forEach((c) => {
    c.classList.toggle("selected", c.dataset.movieId === movieId);
  });

  renderShowtimesForMovie(movieId);
}

function renderShowtimesForMovie(movieId) {
  const container = $("showtimesGrid");
  if (!container) return;

  const relevantShows = showsList.filter((s) => s.movie_id === movieId);
  if (relevantShows.length === 0) {
    container.innerHTML = `<p style="color: var(--text-muted); font-size: 0.9rem;">No shows scheduled for this title.</p>`;
    return;
  }

  container.innerHTML = relevantShows.map((s, idx) => `
    <div class="showtime-card ${idx === 0 ? "selected" : ""}" data-show-id="${s.id}">
      <div class="theatre-name">${s.theatre}</div>
      <div class="theatre-screen">${s.screen} • ${s.sound || "Dolby Atmos"}</div>
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span class="showtime-badge">${s.time}</span>
        <span style="font-size: 0.82rem; font-weight: 700; color: var(--burgundy-primary);">From ₹${s.pricing?.silver || 250}</span>
      </div>
    </div>
  `).join("");

  container.querySelectorAll(".showtime-card").forEach((card) => {
    card.addEventListener("click", () => {
      const sid = card.dataset.showId;
      selectShow(sid);
    });
  });

  if (relevantShows.length > 0) {
    selectShow(relevantShows[0].id);
  }
}

function selectShow(showId) {
  selectedShow = showsList.find((s) => s.id === showId);
  if (!selectedShow) return;

  document.querySelectorAll(".showtime-card").forEach((c) => {
    c.classList.toggle("selected", c.dataset.showId === showId);
  });

  // Load live seat layout from Seat Authority (port 5003)
  loadSeatsForShow(showId);
}

async function loadSeatsForShow(showId) {
  const seatGridEl = $("theatreSeatGrid");
  if (!seatGridEl) return;
  seatGridEl.innerHTML = `<p style="color: var(--text-muted); padding: 20px;">Contacting Seat Authority on port 5003...</p>`;

  try {
    const res = await fetch(`/api/seats/${showId}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    seatDataMap.clear();
    (data.seats || []).forEach((s) => seatDataMap.set(s.seat_id, s));

    renderSeatMap();
  } catch (err) {
    seatGridEl.innerHTML = `
      <div style="padding: 24px; text-align: center; color: var(--status-down);">
        <p style="font-weight: 700; margin-bottom: 6px;">Seat Authority Unavailable</p>
        <p style="font-size: 0.84rem; color: var(--text-secondary);">${err.message}</p>
        <p style="font-size: 0.78rem; color: var(--text-muted); margin-top: 8px;">Distributed Dependency Demonstration: Booking and seat maps depend on Seat Service (port 5003).</p>
      </div>
    `;
  }
}

function renderSeatMap() {
  const seatGridEl = $("theatreSeatGrid");
  if (!seatGridEl) return;

  const rows = ["A", "B", "C", "D"];
  let html = "";

  rows.forEach((rowLetter) => {
    html += `<div class="seat-row">`;
    html += `<span class="row-label">${rowLetter}</span>`;
    html += `<div class="seat-row-seats">`;

    for (let col = 1; col <= 8; col++) {
      const seatId = `${rowLetter}${col}`;
      const seatInfo = seatDataMap.get(seatId) || { status: "AVAILABLE" };
      const isReserved = seatInfo.status === "RESERVED";
      const isSelected = selectedSeat === seatId;

      html += `
        <button class="cinema-seat ${isReserved ? "reserved" : ""} ${isSelected ? "selected" : ""}" 
                data-seat-id="${seatId}" 
                ${isReserved ? "disabled" : ""} 
                title="${seatId} - ${seatInfo.type || "Seat"} (${isReserved ? "Reserved" : "Available"})">
          ${seatId}
        </button>
      `;
    }

    html += `</div>`;
    html += `</div>`;
  });

  seatGridEl.innerHTML = html;

  // Bind seat selection
  seatGridEl.querySelectorAll(".cinema-seat:not(.reserved)").forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedSeat = btn.dataset.seatId;
      renderSeatMap();
      updateBookingSummaryUI();
    });
  });

  // Auto-pick first available if none selected
  if (!selectedSeat || seatDataMap.get(selectedSeat)?.status === "RESERVED") {
    for (let r of rows) {
      for (let c = 1; c <= 8; c++) {
        const sid = `${r}${c}`;
        if (seatDataMap.get(sid)?.status === "AVAILABLE") {
          selectedSeat = sid;
          renderSeatMap();
          updateBookingSummaryUI();
          return;
        }
      }
    }
  }

  updateBookingSummaryUI();
}

function updateBookingSummaryUI() {
  if (!selectedMovie || !selectedShow) return;

  const setT = (id, val) => {
    const el = $(id);
    if (el) el.textContent = val;
  };

  setT("summaryMovieTitle", selectedMovie.title);
  setT("summaryTheatre", `${selectedShow.theatre} • ${selectedShow.screen}`);
  setT("summaryTime", `${selectedShow.time} (Today)`);
  setT("summarySeat", selectedSeat || "None Selected");

  let price = 280;
  if (selectedSeat) {
    const row = selectedSeat[0];
    if (row === "A") price = selectedShow.pricing?.silver || 220;
    else if (row === "B") price = selectedShow.pricing?.gold || 280;
    else if (row === "C") price = selectedShow.pricing?.vip || 350;
    else if (row === "D") price = selectedShow.pricing?.recliner || 480;
  }

  setT("summaryTicketPrice", `₹${price.toFixed(2)}`);
  setT("summaryFee", `₹35.00`);
  setT("summaryTotal", `₹${(price + 35.0).toFixed(2)}`);
}

async function handleBookingSubmit() {
  if (!selectedMovie || !selectedShow || !selectedSeat) {
    toast("Please select a movie, showtime, and available seat.");
    return;
  }

  const customerName = $("customerNameInput")?.value.trim() || "Cinema Patron";
  const btn = $("btnConfirmBooking");
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Processing Transaction...";
  }

  const idempotencyKey = `bms-client-${selectedShow.id}-${selectedSeat}-${Date.now()}`;
  const priceEl = $("summaryTicketPrice");
  const priceVal = priceEl ? parseFloat(priceEl.textContent.replace("₹", "")) || 280 : 280;

  // Animate 3D Request Flow (Gateway -> Booking -> Seat Authority)
  if (topology3D) {
    topology3D.dispatchPacket({ from: "gateway", to: "booking", color: 0x2A6F97 });
    setTimeout(() => {
      topology3D.dispatchPacket({ from: "booking", to: "seats", color: 0x2D6A4F });
    }, 250);
  }

  try {
    const res = await fetch("/bookings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Idempotency-Key": idempotencyKey
      },
      body: JSON.stringify({
        show_id: selectedShow.id,
        seat_id: selectedSeat,
        customer_name: customerName,
        movie_title: selectedMovie.title,
        theatre: selectedShow.theatre,
        show_time: selectedShow.time,
        price: priceVal,
        idempotency_key: idempotencyKey
      })
    });

    const data = await res.json();

    if (res.status === 201 || res.status === 200) {
      toast("Seat successfully reserved! Generating ticket...");
      showTicketConfirmationModal(data.booking || {});
      await loadSeatsForShow(selectedShow.id);
      await fetchBookingHistory();
      logLocalEvent(`Booking confirmed for ${customerName}: Seat ${selectedSeat} (${data.booking?.booking_id})`, "good");
    } else if (res.status === 409) {
      toast("Conflict: That seat was just reserved by another request!");
      alert(`Reservation Rejected (HTTP 409 Conflict):\nSeat ${selectedSeat} is already booked. Concurrency control prevented duplicate assignment.`);
      await loadSeatsForShow(selectedShow.id);
      logLocalEvent(`Reservation rejected: Seat ${selectedSeat} already occupied.`, "bad");
    } else {
      toast(`Reservation failed: ${data.error || "Service Error"}`);
      logLocalEvent(`Reservation failed: ${data.error}`, "bad");
    }
  } catch (err) {
    toast(`Booking error: ${err.message}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = "Confirm & Reserve Seat";
    }
  }
}

function showTicketConfirmationModal(b) {
  const modal = $("ticketModal");
  if (!modal) return;

  const setT = (id, val) => {
    const el = $(id);
    if (el) el.textContent = val;
  };

  setT("modalBookingId", b.booking_id || "BMS-000000");
  setT("modalCustomerName", b.customer_name || "Guest");
  setT("modalMovieTitle", b.movie_title || "Cinema Movie");
  setT("modalTheatre", b.theatre || "Multiplex");
  setT("modalShowTime", b.show_time || "19:00");
  setT("modalSeatId", b.seat_id || "A1");
  setT("modalTotalAmount", `₹${b.total_amount || "315.00"}`);
  setT("modalTimestamp", b.created_at || new Date().toLocaleString());

  modal.classList.add("show");
}

async function fetchBookingHistory() {
  try {
    const res = await fetch("/bookings/history");
    if (!res.ok) return;
    const data = await res.json();
    bookingHistory = data.bookings || [];
    renderBookingHistoryTable();
  } catch (e) {
    console.error("Failed to load booking history:", e);
  }
}

function renderBookingHistoryTable() {
  const tbody = $("bookingHistoryTbody");
  if (!tbody) return;

  if (bookingHistory.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted); padding: 16px;">No reservations recorded in this demo session.</td></tr>`;
    return;
  }

  tbody.innerHTML = bookingHistory.map((b) => `
    <tr>
      <td class="mono" style="font-weight: 700; color: var(--burgundy-primary);">${b.booking_id}</td>
      <td><strong>${b.customer_name}</strong></td>
      <td>${b.movie_title}</td>
      <td>${b.show_id} • <strong>${b.seat_id}</strong></td>
      <td>₹${b.total_amount}</td>
      <td><span class="badge up">${b.status}</span></td>
    </tr>
  `).join("");
}

async function resetCurrentShowSeats() {
  if (!selectedShow) return;
  if (!confirm(`Reset all reservations for ${selectedShow.id} back to default state?`)) return;

  try {
    const res = await fetch(`/seats/reset/${selectedShow.id}`, { method: "POST" });
    if (res.ok) {
      toast(`Seat reservations for ${selectedShow.id} reset.`);
      loadSeatsForShow(selectedShow.id);
    }
  } catch (err) {
    toast(`Failed to reset seats: ${err.message}`);
  }
}

// ==========================================================================
// Telemetry & Event Logging
// ==========================================================================

async function fetchTelemetry() {
  try {
    const res = await fetch("/cluster/telemetry");
    if (!res.ok) return;
    const data = await res.json();
    eventsList = data.events || [];
    renderEventLog();
  } catch (e) {}
}

function renderEventLog() {
  const root = $("eventLog");
  if (!root) return;

  if (eventsList.length === 0) {
    root.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-muted);">No cluster events logged yet.</div>`;
    return;
  }

  root.innerHTML = eventsList.map((e) => `
    <div class="log-item">
      <span class="log-time">${e.time}</span>
      <span class="log-dot ${e.kind || "info"}"></span>
      <span class="log-message">${escapeHtml(e.message)}</span>
    </div>
  `).join("");
}

function logLocalEvent(message, kind = "info") {
  eventsList.unshift({
    time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
    message,
    kind
  });
  renderEventLog();
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function bindInspectorControls() {
  $("btnClearLogBtn")?.addEventListener("click", () => {
    eventsList = [];
    renderEventLog();
  });
}

function toast(message) {
  const el = $("toastNotice");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}
