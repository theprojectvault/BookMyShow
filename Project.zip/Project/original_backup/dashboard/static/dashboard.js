const $ = (id) => document.getElementById(id);
let events = [];
let selectedSeat = "A1";
let lastMovieReplica = null;
const seats = Array.from({length:3},(_,r)=>Array.from({length:8},(_,i)=>String.fromCharCode(65+r)+(i+1))).flat();

function timeNow(){return new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});}
function logEvent(message, kind="info"){
  events.unshift({time:timeNow(),message,kind});
  events=events.slice(0,30);
  $("eventCount").textContent=events.length;
  renderLog();
}
function renderLog(){
  const root=$("eventLog");
  if(!events.length){root.innerHTML='<div class="empty-log">Your tests will appear here with timestamps and results.</div>';return;}
  root.innerHTML=events.map(e=>`<div class="log-item"><span class="log-time">${e.time}</span><span class="log-dot ${e.kind==="good"?"good":e.kind==="bad"?"bad":""}"></span><span class="log-message">${escapeHtml(e.message)}</span></div>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function setBadge(el,status){
  if(!el)return;
  el.className="badge "+(status==="UP"?"up":status==="DOWN"?"down":"neutral");
  el.textContent=status;
}
function setDot(el,status){
  el.className="dot "+(status==="UP"?"up":status==="DOWN"?"down":"neutral");
}
async function getJson(url,opts={}){
  const res=await fetch(url,opts);
  let data={};
  try{data=await res.json()}catch{}
  if(!res.ok){const err=new Error(data.message||data.error||`HTTP ${res.status}`);err.status=res.status;err.data=data;throw err;}
  return data;
}
async function refreshStatus(){
  $("refreshBtn").disabled=true;
  try{
    const data=await getJson("/cluster/status");
    const services=data.services||{};
    const names=["movie_A","movie_B","booking","seats"];
    let online=0;
    names.forEach(name=>{
      const status=services[name]?.status||"DOWN";
      if(status==="UP")online++;
      setBadge(document.querySelector(`[data-badge="${name}"]`),status);
    });
    $("onlineCount").innerHTML=`${online}<small> / 4</small>`;
    const gatewayStatus=data.gateway||"DOWN";
    $("gatewayState").innerHTML=`<span class="dot ${gatewayStatus==="UP"?"up":"down"}"></span> ${gatewayStatus}`;
    $("gatewayBadge").className="badge "+(gatewayStatus==="UP"?"up":"down");
    $("gatewayBadge").textContent=gatewayStatus;
    const redisUp=services.seats?.details?.redis==="UP";
    $("redisState").innerHTML=`<span class="dot ${redisUp?"up":"down"}"></span> ${redisUp?"Connected":"Unavailable"}`;
    setBadge($("redisBadge"),redisUp?"UP":"DOWN");
    $("faultResult").textContent=online===4
      ?"All four backend services are reachable. Stop Movie Server A to demonstrate failover."
      :`${online} of 4 backend services are reachable. Check the server terminals for the service marked DOWN.`;
    await refreshSeats(false);
  }catch(e){
    $("gatewayState").textContent="Unavailable";
    $("gatewayBadge").className="badge down";$("gatewayBadge").textContent="DOWN";
    $("faultResult").textContent="Could not contact the gateway. Confirm Terminal 4 is running on port 8000.";
    logEvent("Cluster status check failed: "+e.message,"bad");
  }finally{$("refreshBtn").disabled=false;}
}
async function sendMovieRequest(){
  $("movieBtn").disabled=true;
  $("movieResult").textContent="Request in progress…";
  try{
    const data=await getJson("/movies");
    const replica=data.service||"Movie service";
    lastMovieReplica=data.routed_to||"unknown";
    $("movieResult").textContent=`Responded by ${replica}`;
    $("movieDetail").textContent=`Gateway routed this request to ${lastMovieReplica}. ${Array.isArray(data.movies)?data.movies.length+" movies returned.":""}`;
    logEvent(`GET /movies → ${replica} at ${lastMovieReplica}`,"good");
    toast("Movie request completed successfully.");
  }catch(e){
    $("movieResult").textContent="Request failed";
    $("movieDetail").textContent=e.message;
    logEvent("Movie request failed: "+e.message,"bad");
    toast("Movie service request failed.");
  }finally{$("movieBtn").disabled=false;}
}
function buildSeatOptions(){
  $("seatSelect").innerHTML=seats.map(s=>`<option value="${s}">${s}</option>`).join("");
  $("seatSelect").value=selectedSeat;
}
function renderSeats(data){
  const statusMap=new Map((data.seats||[]).map(s=>[s.seat_id,s.status]));
  $("seatGrid").innerHTML=seats.map(s=>{
    const reserved=statusMap.get(s)==="RESERVED";
    const selected=s===selectedSeat;
    return `<button class="seat ${reserved?"reserved":""} ${selected&&!reserved?"selected":""}" data-seat="${s}" ${reserved?"disabled":""} title="${s}: ${reserved?"Reserved":"Available"}">${s}</button>`;
  }).join("");
  $("seatGrid").querySelectorAll("[data-seat]").forEach(btn=>btn.addEventListener("click",()=>{
    selectedSeat=btn.dataset.seat;$("seatSelect").value=selectedSeat;refreshSeats(false);
  }));
}
async function refreshSeats(writeLog=true){
  try{
    const show=$("showSelect").value;
    const data=await getJson(`/api/seats/${encodeURIComponent(show)}`);
    renderSeats(data);
    if(writeLog)logEvent(`Seat state refreshed for ${show}.`,"good");
  }catch(e){
    $("seatGrid").innerHTML='<div class="empty-log">Seat service unavailable. Check Terminal 3.</div>';
    if(writeLog)logEvent("Seat status check failed: "+e.message,"bad");
  }
}
async function reserveSeat(){
  $("bookBtn").disabled=true;
  const show_id=$("showSelect").value, seat_id=$("seatSelect").value;
  const key=`dashboard-${show_id}-${seat_id}-${Date.now()}`;
  $("bookingResult").textContent="Sending reservation…";
  try{
    const data=await getJson("/bookings",{method:"POST",headers:{"Content-Type":"application/json","Idempotency-Key":key},body:JSON.stringify({show_id,seat_id,idempotency_key:key})});
    const booking=data.booking||{};
    $("bookingResult").textContent=`${data.status||"SUCCESS"} · ${seat_id}`;
    $("bookingDetail").textContent=`Booking ID: ${booking.booking_id||"returned"} · Service: ${data.service||"booking service"}`;
    logEvent(`Seat ${seat_id} for ${show_id} reserved successfully. Booking ID ${booking.booking_id||"created"}.`,"good");
    toast(`Seat ${seat_id} reserved.`);
  }catch(e){
    $("bookingResult").textContent=e.status===409?"Reservation rejected · seat already reserved":"Reservation failed";
    $("bookingDetail").textContent=e.message;
    logEvent(`Reservation ${show_id}/${seat_id} rejected or failed: ${e.message}`,e.status===409?"bad":"bad");
    toast(e.status===409?"Seat is already reserved.":"Reservation failed.");
  }finally{
    $("bookBtn").disabled=false;
    await refreshSeats(false);
  }
}
$("refreshBtn").addEventListener("click",()=>{logEvent("Manual cluster status refresh requested.");refreshStatus();});
$("faultCheckBtn").addEventListener("click",()=>{logEvent("Cluster health rechecked for fault-tolerance experiment.");refreshStatus();});
$("movieBtn").addEventListener("click",sendMovieRequest);
$("bookBtn").addEventListener("click",reserveSeat);
$("checkSeatsBtn").addEventListener("click",()=>refreshSeats(true));
$("showSelect").addEventListener("change",()=>refreshSeats(false));
$("seatSelect").addEventListener("change",()=>{selectedSeat=$("seatSelect").value;refreshSeats(false);});
$("clearLogBtn").addEventListener("click",()=>{events=[];$("eventCount").textContent="0";renderLog();});
function toast(message){
  const el=$("toast");el.textContent=message;el.classList.add("show");
  clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>el.classList.remove("show"),2600);
}
buildSeatOptions();
logEvent("Dashboard loaded. Checking service health.");
refreshStatus();
setInterval(refreshStatus,10000);
