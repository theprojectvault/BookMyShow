# BookMyShow Distributed Computing Backend

This is a local multi-process distributed-systems demonstration for VS Code, not a full commercial ticketing system.

## Services and ports

- Gateway: `127.0.0.1:8000`
- Movie replica A: `127.0.0.1:5001`
- Booking service: `127.0.0.1:5002`
- Seat service: `127.0.0.1:5003`
- Movie replica B: `127.0.0.1:5004`
- Redis: `127.0.0.1:6379`

The gateway round-robins movie requests between two independent movie processes and fails over when one is unavailable. The booking service calls the seat service over HTTP. The seat service uses an atomic Redis Lua script to prevent duplicate seat reservations. Booking records and idempotency references are stored in Redis.

## Requirements

- Python 3.10+
- Docker Desktop with Docker Compose
- VS Code

## Setup in Windows PowerShell

Run from the project root (the folder containing `requirements.txt`):

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
docker compose up -d
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

## Start services in separate VS Code terminals

Open five terminals. In each, change to the project root and activate `.venv` if necessary.

Terminal 1 — Movie replica A:
```powershell
$env:PORT="5001"; $env:INSTANCE_NAME="movie-A"; python -m movie_service.app
```

Terminal 2 — Booking service:
```powershell
python -m booking_service.app
```

Terminal 3 — Seat service:
```powershell
python -m seat_service.app
```

Terminal 4 — Gateway:
```powershell
python -m gateway.app
```

Terminal 5 — Movie replica B:
```powershell
$env:PORT="5004"; $env:INSTANCE_NAME="movie-B"; python -m movie_service.app
```

Keep all five terminals running.

## Test the cluster

- Gateway info: http://127.0.0.1:8000/
- Cluster health: http://127.0.0.1:8000/cluster/status
- Movies: http://127.0.0.1:8000/movies (refresh repeatedly to see replicas alternate)
- Shows: http://127.0.0.1:8000/shows
- Seat state: http://127.0.0.1:5003/seats/S201

Book a seat from PowerShell:
```powershell
$body = @{ show_id = "S201"; seat_id = "A1"; idempotency_key = "demo-booking-001" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/bookings -ContentType "application/json" -Body $body
```

Try the same seat with a different idempotency key. The second request should return HTTP 409. Repeat the original key to demonstrate idempotency.

## Demonstrate failover

1. Check `/cluster/status` and confirm both movie replicas are UP.
2. Stop the movie-A terminal with Ctrl+C.
3. Refresh `/movies`; the gateway should use movie-B.
4. Restart movie-A and check status again.

## Reset demo data

This deletes all data in the configured Redis database. Do not run if that database contains anything else.
```powershell
docker exec bookmyshow-redis redis-cli FLUSHDB
```

## Limitations

- All services run on one computer but are separate processes communicating over HTTP.
- Redis is shared state for this local demo, not a production deployment.
- The booking flow reserves the seat before writing the booking record. A crash between those steps can leave a reservation without a booking record. Production systems need durable transaction/saga handling, reservation expiry, and reconciliation.
- Do not use for real payments or real customer data.


## Clean presentation dashboard

The gateway now serves a light, presentation-friendly dashboard at `http://127.0.0.1:8000/`.
It shows service health, architecture, movie replica routing, seat reservation results, seat state, and a local experiment log. Keep all five service terminals and Redis running while demonstrating it.

Suggested demo for an instructor:
1. Open the dashboard and point out the gateway and four backend services.
2. Click **Send movie request** repeatedly to show routing between movie replicas.
3. Reserve a seat, then try the same seat with another request to show a conflict.
4. Stop Movie Server A with Ctrl+C and click **Send movie request**. It should fail over to Movie Server B.
5. Restart Movie Server A and click **Refresh status**.

The dashboard visualizes live API responses; it is not a separate mockup. It does not replace the independent service processes.
