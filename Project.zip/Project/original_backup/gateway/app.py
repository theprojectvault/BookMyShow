import itertools
import requests
from flask import Flask, jsonify, request, render_template
from common.config import MOVIE_REPLICAS, BOOKING_SERVICE_URL, SEAT_SERVICE_URL, REQUEST_TIMEOUT

app = Flask(
    __name__,
    template_folder="../dashboard",
    static_folder="../dashboard/static",
)
counter = itertools.count()

def try_movie_replicas(path):
    replicas = MOVIE_REPLICAS
    start = next(counter) % len(replicas)
    errors = []
    for offset in range(len(replicas)):
        base = replicas[(start + offset) % len(replicas)]
        try:
            response = requests.get(f"{base}{path}", timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            payload = response.json()
            payload["routed_to"] = base
            return jsonify(payload), response.status_code
        except (requests.RequestException, ValueError) as exc:
            errors.append(f"{base}: {exc}")
    return jsonify(error="All movie service replicas are unavailable", details=errors), 503

@app.get("/")
def dashboard():
    return render_template("index.html")

@app.get("/health")
def health():
    return jsonify(status="UP", service="gateway")

@app.get("/movies")
def movies():
    return try_movie_replicas("/movies")

@app.get("/shows")
def shows():
    return try_movie_replicas("/shows")

@app.get("/cluster/status")
def cluster_status():
    services = {}
    for name, url in [
        ("movie_A", MOVIE_REPLICAS[0]),
        ("movie_B", MOVIE_REPLICAS[1]),
        ("booking", BOOKING_SERVICE_URL),
        ("seats", SEAT_SERVICE_URL),
    ]:
        try:
            response = requests.get(f"{url}/health", timeout=REQUEST_TIMEOUT)
            try:
                details = response.json()
            except ValueError:
                details = {"message": response.text[:200]}
            services[name] = {
                "status": "UP" if response.ok else "DOWN",
                "url": url,
                "details": details,
            }
        except (requests.RequestException, ValueError) as exc:
            services[name] = {"status": "DOWN", "url": url, "error": str(exc)}
    return jsonify(gateway="UP", services=services)

@app.get("/api/seats/<show_id>")
def seat_status(show_id):
    try:
        response = requests.get(f"{SEAT_SERVICE_URL}/seats/{show_id}", timeout=REQUEST_TIMEOUT)
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException as exc:
        return jsonify(error="Seat service unavailable", detail=str(exc)), 503

@app.post("/bookings")
def bookings():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="Send a JSON request body."), 400
    try:
        headers = {}
        if request.headers.get("Idempotency-Key"):
            headers["Idempotency-Key"] = request.headers["Idempotency-Key"]
        response = requests.post(
            f"{BOOKING_SERVICE_URL}/bookings",
            json=data,
            headers=headers,
            timeout=REQUEST_TIMEOUT + 2,
        )
        try:
            payload = response.json()
        except ValueError:
            payload = {"error": response.text[:300]}
        return jsonify(payload), response.status_code
    except requests.RequestException as exc:
        return jsonify(error="Booking service unavailable", detail=str(exc)), 503

@app.get("/bookings/<booking_id>")
def get_booking(booking_id):
    try:
        response = requests.get(
            f"{BOOKING_SERVICE_URL}/bookings/{booking_id}",
            timeout=REQUEST_TIMEOUT,
        )
        return (response.text, response.status_code, {"Content-Type": "application/json"})
    except requests.RequestException as exc:
        return jsonify(error="Booking service unavailable", detail=str(exc)), 503

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False, threaded=True)
