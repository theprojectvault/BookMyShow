# Run from project root after all services are running.
Write-Host "`n--- Cluster status ---"
Invoke-RestMethod http://127.0.0.1:8000/cluster/status | ConvertTo-Json -Depth 6

Write-Host "`n--- Movies (run repeatedly to observe round-robin) ---"
1..4 | ForEach-Object {
    Invoke-RestMethod http://127.0.0.1:8000/movies | Select-Object routed_to, service
}

Write-Host "`n--- Reserve seat A1 for show S201 ---"
$body = @{ show_id = "S201"; seat_id = "A1"; idempotency_key = "test-001" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/bookings -ContentType "application/json" -Body $body
