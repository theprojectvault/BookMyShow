import os
from flask import Flask, jsonify, request
import redis
from common.config import REDIS_URL

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5003"))
INSTANCE = os.getenv("INSTANCE_NAME", f"seat-{PORT}")
r = redis.Redis.from_url(REDIS_URL, decode_responses=True)

RESERVE_SCRIPT = r.register_script('''
local key = KEYS[1]
local booking_id = ARGV[1]
if redis.call("EXISTS", key) == 1 then
  return 0
end
redis.call("HSET", key, "booking_id", booking_id, "status", "RESERVED")
return 1
''')

@app.get("/health")
def health():
    try:
        r.ping()
        return jsonify(status="UP", service="seat-service", instance=INSTANCE, redis="UP", port=PORT)
    except redis.RedisError as exc:
        return jsonify(status="DOWN", service="seat-service", error=str(exc)), 503

@app.get("/seats/<show_id>")
def seats(show_id):
    seat_ids = [f"{row}{number}" for row in "ABC" for number in range(1, 9)]
    output = []
    for seat_id in seat_ids:
        record = r.hgetall(f"seat:{show_id}:{seat_id}")
        output.append({"seat_id": seat_id, "status": record.get("status", "AVAILABLE")})
    return jsonify(show_id=show_id, seats=output, service=INSTANCE)

@app.post("/seats/reserve")
def reserve():
    data = request.get_json(silent=True) or {}
    show_id = str(data.get("show_id", "")).strip()
    seat_id = str(data.get("seat_id", "")).strip().upper()
    booking_id = str(data.get("booking_id", "")).strip()
    valid_seats = {f"{row}{number}" for row in "ABC" for number in range(1, 9)}
    if not show_id or not booking_id or seat_id not in valid_seats:
        return jsonify(error="Provide show_id, booking_id, and valid seat_id (A1-C8)."), 400
    try:
        result = RESERVE_SCRIPT(keys=[f"seat:{show_id}:{seat_id}"], args=[booking_id])
        if int(result) == 0:
            existing = r.hgetall(f"seat:{show_id}:{seat_id}")
            return jsonify(status="CONFLICT", message="Seat is already reserved.", seat_id=seat_id,
                           existing_booking_id=existing.get("booking_id")), 409
        return jsonify(status="RESERVED", show_id=show_id, seat_id=seat_id,
                       booking_id=booking_id, service=INSTANCE), 201
    except redis.RedisError as exc:
        return jsonify(error="Redis unavailable", detail=str(exc)), 503

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
