import os
import uuid
import requests
import redis
from flask import Flask, jsonify, request
from common.config import REDIS_URL, SEAT_SERVICE_URL, REQUEST_TIMEOUT

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5002"))
INSTANCE = os.getenv("INSTANCE_NAME", f"booking-{PORT}")
r = redis.Redis.from_url(REDIS_URL, decode_responses=True)

@app.get("/health")
def health():
    try:
        r.ping()
        return jsonify(status="UP", service="booking-service", instance=INSTANCE, redis="UP", port=PORT)
    except redis.RedisError as exc:
        return jsonify(status="DOWN", service="booking-service", error=str(exc)), 503

@app.post("/bookings")
def create_booking():
    data = request.get_json(silent=True) or {}
    show_id = str(data.get("show_id", "")).strip()
    seat_id = str(data.get("seat_id", "")).strip().upper()
    idempotency_key = request.headers.get("Idempotency-Key") or str(data.get("idempotency_key", "")).strip()
    if not show_id or not seat_id:
        return jsonify(error="show_id and seat_id are required."), 400
    if not idempotency_key:
        return jsonify(error="Provide an Idempotency-Key header or idempotency_key field."), 400

    idem_key = f"idempotency:{idempotency_key}"
    existing_id = r.get(idem_key)
    if existing_id:
        existing = r.hgetall(f"booking:{existing_id}")
        if existing:
            return jsonify(status="EXISTING", booking=existing, service=INSTANCE), 200

    booking_id = str(uuid.uuid4())
    try:
        response = requests.post(
            f"{SEAT_SERVICE_URL}/seats/reserve",
            json={"show_id": show_id, "seat_id": seat_id, "booking_id": booking_id},
            timeout=REQUEST_TIMEOUT,
        )
    except requests.RequestException as exc:
        return jsonify(error="Seat service unavailable", detail=str(exc)), 503

    if response.status_code == 409:
        return jsonify(status="REJECTED", message="Seat is already reserved.", seat_id=seat_id), 409
    if response.status_code not in (200, 201):
        return jsonify(error="Seat reservation failed", upstream_status=response.status_code,
                       detail=response.text[:300]), 502

    booking = {
        "booking_id": booking_id,
        "show_id": show_id,
        "seat_id": seat_id,
        "status": "CONFIRMED",
        "created_by": INSTANCE,
    }
    pipe = r.pipeline(transaction=True)
    pipe.hset(f"booking:{booking_id}", mapping=booking)
    pipe.set(idem_key, booking_id)
    pipe.execute()
    return jsonify(status="CONFIRMED", booking=booking, seat_service=response.json(),
                   service=INSTANCE), 201

@app.get("/bookings/<booking_id>")
def get_booking(booking_id):
    booking = r.hgetall(f"booking:{booking_id}")
    if not booking:
        return jsonify(error="Booking not found", booking_id=booking_id), 404
    return jsonify(booking=booking, service=INSTANCE)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
