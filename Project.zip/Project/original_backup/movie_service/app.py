import os
from flask import Flask, jsonify

app = Flask(__name__)
PORT = int(os.getenv("PORT", "5001"))
INSTANCE = os.getenv("INSTANCE_NAME", f"movie-{PORT}")

MOVIES = [
    {"id": "M101", "title": "Interstellar", "language": "English", "genre": "Sci-Fi"},
    {"id": "M102", "title": "RRR", "language": "Telugu", "genre": "Action"},
    {"id": "M103", "title": "Dune: Part Two", "language": "English", "genre": "Sci-Fi"},
]

@app.get("/health")
def health():
    return jsonify(status="UP", service="movie-service", instance=INSTANCE, port=PORT)

@app.get("/movies")
def movies():
    return jsonify(service=INSTANCE, movies=MOVIES)

@app.get("/shows")
def shows():
    return jsonify(service=INSTANCE, shows=[
        {"id": "S201", "movie_id": "M101", "theatre": "City Cinemas", "time": "18:30"},
        {"id": "S202", "movie_id": "M102", "theatre": "Grand Screens", "time": "20:00"},
        {"id": "S203", "movie_id": "M103", "theatre": "Metro Multiplex", "time": "21:15"},
    ])

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
