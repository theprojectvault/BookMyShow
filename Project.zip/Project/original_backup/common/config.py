import os

REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
MOVIE_SERVICE_URL = os.getenv("MOVIE_SERVICE_URL", "http://127.0.0.1:5001")
BOOKING_SERVICE_URL = os.getenv("BOOKING_SERVICE_URL", "http://127.0.0.1:5002")
SEAT_SERVICE_URL = os.getenv("SEAT_SERVICE_URL", "http://127.0.0.1:5003")
MOVIE_REPLICAS = [
    os.getenv("MOVIE_SERVICE_A_URL", "http://127.0.0.1:5001"),
    os.getenv("MOVIE_SERVICE_B_URL", "http://127.0.0.1:5004"),
]
REQUEST_TIMEOUT = float(os.getenv("REQUEST_TIMEOUT", "2.5"))
