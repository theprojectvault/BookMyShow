# BookMyShow 3D Distributed Computing Platform

An advanced, interactive **3D Distributed Systems Platform** and cinema-ticketing demonstration built with **Python 3, Flask, Redis, Three.js, and modern Vanilla CSS/JS**.

Designed for Distributed Computing academic demonstration, this project provides a real multi-process microservice cluster communicating over HTTP with real load-balancing, failover, atomic mutex concurrency control, and 3D visual telemetry.

---

## 1. System Architecture

```mermaid
graph TD
    Client["Browser Client / UI Dashboard<br>(Three.js 3D Viewport)"]
    Gateway["API Gateway Hub<br>(Port 8000)<br>Reverse Proxy & Round-Robin Load Balancer"]
    MovieA["Movie Server A<br>(Port 5001)<br>Catalog Replica 1"]
    MovieB["Movie Server B<br>(Port 5004)<br>Catalog Replica 2"]
    Booking["Booking Service<br>(Port 5002)<br>Transaction Coordinator & Idempotency"]
    Seats["Seat Authority<br>(Port 5003)<br>Inventory Mutex Provider"]
    Redis[("Redis Shared State<br>(Port 6379)<br>Atomic Lua Mutex")]

    Client -->|HTTP REST| Gateway
    Gateway -->|Round-Robin / Failover| MovieA
    Gateway -->|Round-Robin / Failover| MovieB
    Gateway -->|IPC REST| Booking
    Booking -->|IPC REST| Seats
    Seats -->|Atomic Lua Script| Redis
```

### Microservices & Port Map

| Component | Port | Technology | Role & DC Concepts |
| :--- | :---: | :---: | :--- |
| **API Gateway Hub** | `8000` | Python / Flask | Client entry point, round-robin load balancer, health monitor, failover retry engine. |
| **Movie Server A** | `5001` | Python / Flask | Movie catalog replica 1, showtime provider, independent failure unit. |
| **Movie Server B** | `5004` | Python / Flask | Movie catalog replica 2, identical replicated state, secondary failover node. |
| **Booking Service** | `5002` | Python / Flask | Transaction coordinator, idempotency key validator, service dependency consumer. |
| **Seat Authority** | `5003` | Python / Flask | Seat inventory master, atomic compare-and-swap reservation engine, race condition barrier. |
| **Redis Shared State** | `6379` | Redis / Lua | Atomic key-value datastore, single-threaded Lua script execution, memory mutex fallback. |

---

## 2. Interactive 3D Experience (Three.js)

The application features a fully interactive 3D cluster topology rendered in real time using Three.js:
- **Central API Gateway Node**: Elevated hexagonal hub commanding the cluster center.
- **Movie Replicas A & B**: Cylindrical monoliths on the left replica wing.
- **Booking & Seat Nodes**: Architectural service towers on the right wing.
- **Redis Foundation**: Glowing atomic base beneath the Seat Authority.
- **Live 3D Data Packets**: When you click "Send Movie Request" or "Reserve Seat", glowing light packets travel along curved spline conduits between nodes in real time.
- **Dynamic Failover Animation**: If Movie Server A is down, a packet heading toward A detects the fault, flashes crimson red with particle sparks, and dynamically reroutes along a curved path to Movie Server B!
- **State Feedback**: Green glowing rings for `UP`, pulsating crimson beacons for `DOWN`, and energy wavefronts during `RECOVERY`.
- **Interactive Controls**: Hover over nodes to preview metrics, click nodes to open the real-time Node Telemetry Inspector, and toggle camera preset angles.

---

## 3. Windows Setup & Running the Services

### Prerequisites
- Python 3.10+ (Python 3.14 recommended)
- Windows PowerShell

### Quick Setup

Open PowerShell in the project directory:

```powershell
# Create virtual environment
py -m venv .venv

# Activate environment
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt
```

---

### Option A: One-Click Cluster Orchestrator (Recommended)

Run the Python supervisor to start all 5 microservices concurrently:

```powershell
python orchestrator.py
```
To stop all services, simply press `Ctrl + C` in that terminal.

---

### Option B: One-Click Windows PowerShell Launcher

Launch each service into its own distinct background PowerShell window:

```powershell
.\start_all.ps1
```

---

### Option C: Five Independent VS Code Terminals (Manual)

Open 5 separate terminals in VS Code. In each, activate `.venv`:

**Terminal 1 — Movie Replica A:**
```powershell
$env:PORT="5001"; $env:INSTANCE_NAME="movie-A"; python -m movie_service.app
```

**Terminal 2 — Movie Replica B:**
```powershell
$env:PORT="5004"; $env:INSTANCE_NAME="movie-B"; python -m movie_service.app
```

**Terminal 3 — Booking Service:**
```powershell
python -m booking_service.app
```

**Terminal 4 — Seat Authority:**
```powershell
python -m seat_service.app
```

**Terminal 5 — API Gateway:**
```powershell
python -m gateway.app
```

Now open **http://127.0.0.1:8000/** in your browser.

---

## 4. The 12 Distributed Computing Concepts Implemented

1. **Distributed Service Architecture**: Five independent process boundaries communicating strictly over network protocols without shared in-process memory.
2. **Client-Server Architecture**: Browser interacts only with the API Gateway; internal service topologies are hidden from the client.
3. **Load Balancing**: Gateway implements round-robin distribution between Movie Server A (`5001`) and Movie Server B (`5004`), tracking response times and request indexes.
4. **Replication**: Movie catalog and showtimes are identically replicated on two separate server nodes to eliminate single-point-of-failure bottlenecks.
5. **Fault Tolerance**: The gateway intercepts connection errors or HTTP 503s from an unresponsive replica and immediately retries the alternative replica.
6. **Failover and Recovery**: Seamless failover to Movie Server B when Movie Server A is halted, and immediate re-integration into the cluster pool upon recovery.
7. **Inter-Process Communication (IPC)**: Standardized JSON envelopes exchanged over HTTP REST with timeouts to avoid deadlock.
8. **Consistency**: A seat cannot be double-booked. Redis state ensures identical views across all processes.
9. **Concurrency Control**: Seat Authority runs atomic Redis Lua scripts (`EXISTS` followed by `HSET`) in an indivisible step, preventing race conditions.
10. **Monitoring & Observability**: Continuous health probing at `/cluster/status`, real-time millisecond latency tracking, and event timelines.
11. **Service Dependency Handling**: Booking Service detects if downstream Seat Service is offline and returns a structured `503 Service Dependency Failure` error.
12. **Scalability Concepts**: Horizontal scaling pattern demonstrated—additional replicas (e.g. `movie-C` on 5005) require only adding an entry to `MOVIE_REPLICAS` in `common/config.py`.

---

## 5. Academic Demonstration Script for Professors / Evaluators

Follow this exact walkthrough during your academic project evaluation:

| Step | Action | What to Point Out to the Evaluator |
| :---: | :--- | :--- |
| **1** | Open `http://127.0.0.1:8000/` | Show the **Live 3D Topology**. Point out the 5 independent service nodes, port badges, and the Redis datastore. |
| **2** | Click **Load Balancing Lab** | Click **Send 1x Movie Request** multiple times. Show how the gateway alternates between **Movie Server A** (`:5001`) and **Movie Server B** (`:5004`) with real measured timings. |
| **3** | Click **Fault Tolerance Lab** | Click **Inject Failure** on Movie Server A (or kill Terminal 1 with `Ctrl+C`). Point out Movie Server A turning red in the 3D scene. |
| **4** | Send Movie Request again | Show that the request **succeeds immediately**! The gateway caught the failure and failed over to Movie Server B without any client error. |
| **5** | Click **Consistency & Race Lab** | Click **Trigger Concurrent Race Test (3 Competing Clients)**. Show that 3 simultaneous requests were sent for Seat B4 at the same millisecond: **1 won (HTTP 201 Created)** and **2 were rejected (HTTP 409 Conflict)** due to the atomic Lua mutex script! |
| **6** | Click **Cinema Booking** tab | Select *Interstellar*, pick a showtime, choose seat A1, and click **Confirm & Reserve Seat**. Show the generated Cinema Ticket Pass and booking history. |
| **7** | Click **12 DC Concepts** tab | Review the academic concepts table showing how each theoretical principle is implemented in the codebase. |

---

## 6. Running Automated Tests

To run the automated verification suite:

```powershell
pytest tests/ -v
```
