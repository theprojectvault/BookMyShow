"""
BookMyShow Distributed Computing Cluster Orchestrator
Launches and monitors all 5 microservice processes concurrently:
  1. API Gateway         (Port 8000)
  2. Movie Replica A     (Port 5001)
  3. Booking Service     (Port 5002)
  4. Seat Authority      (Port 5003)
  5. Movie Replica B     (Port 5004)
"""

import sys
import os
import time
import subprocess
import signal

PYTHON_EXE = sys.executable

SERVICES = [
    {
        "name": "Movie Replica A",
        "cmd": [PYTHON_EXE, "-m", "movie_service.app"],
        "env": {"PORT": "5001", "INSTANCE_NAME": "movie-A"},
        "port": 5001
    },
    {
        "name": "Movie Replica B",
        "cmd": [PYTHON_EXE, "-m", "movie_service.app"],
        "env": {"PORT": "5004", "INSTANCE_NAME": "movie-B"},
        "port": 5004
    },
    {
        "name": "Booking Service",
        "cmd": [PYTHON_EXE, "-m", "booking_service.app"],
        "env": {"PORT": "5002", "INSTANCE_NAME": "booking-5002"},
        "port": 5002
    },
    {
        "name": "Seat Authority",
        "cmd": [PYTHON_EXE, "-m", "seat_service.app"],
        "env": {"PORT": "5003", "INSTANCE_NAME": "seat-5003"},
        "port": 5003
    },
    {
        "name": "API Gateway Hub",
        "cmd": [PYTHON_EXE, "-m", "gateway.app"],
        "env": {"PORT": "8000"},
        "port": 8000
    }
]

processes = []

def start_cluster():
    print("=" * 68)
    print("  BOOKMYSHOW 3D DISTRIBUTED COMPUTING CLUSTER LAUNCHER")
    print("=" * 68)
    print(f"Python Runtime: {PYTHON_EXE}")
    print(f"Project Directory: {os.getcwd()}\n")

    for s in SERVICES:
        env = os.environ.copy()
        env.update(s["env"])
        
        print(f"[*] Starting {s['name']:<20} on http://127.0.0.1:{s['port']} ...", end="", flush=True)
        # Pass DEVNULL or inherit console so Flask logs do not block Windows pipe buffer
        proc = subprocess.Popen(
            s["cmd"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        processes.append((s, proc))
        print(f" [PID {proc.pid}]")
        time.sleep(0.4)

    print("\n" + "=" * 68)
    print("  ALL 5 DISTRIBUTED SERVICES ARE ONLINE!")
    print("  Access the 3D Dashboard: http://127.0.0.1:8000/")
    print("  Press Ctrl+C to terminate all services gracefully.")
    print("=" * 68 + "\n")

    try:
        while True:
            time.sleep(1)
            # Check if any process terminated unexpectedly
            for s, p in processes:
                poll = p.poll()
                if poll is not None:
                    print(f"[!] Warning: {s['name']} (PID {p.pid}) exited with code {poll}")
    except KeyboardInterrupt:
        print("\n[*] Shutting down cluster services...")
        stop_cluster()

def stop_cluster():
    for s, p in processes:
        if p.poll() is None:
            print(f"[*] Stopping {s['name']} (PID {p.pid})...")
            p.terminate()
            try:
                p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                p.kill()
    print("[*] All services terminated cleanly.")

if __name__ == "__main__":
    start_cluster()
